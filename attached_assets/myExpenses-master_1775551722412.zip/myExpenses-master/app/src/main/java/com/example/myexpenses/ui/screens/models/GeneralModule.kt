package com.example.myexpenses.ui.screens.models

import androidx.lifecycle.ViewModel
import com.example.myexpenses.data.db.ExpenseDao
import com.example.myexpenses.data.db.General

class GeneralModule(private val expenseDao: ExpenseDao) : ViewModel() {
    suspend fun get(): List<General> {
        return expenseDao.getGeneral()
    }
    suspend fun insert(general: General): Long {
        return expenseDao.insertGeneral(general)
    }
    suspend fun update(general: General) {
        expenseDao.updateGeneral(general)
    }
}