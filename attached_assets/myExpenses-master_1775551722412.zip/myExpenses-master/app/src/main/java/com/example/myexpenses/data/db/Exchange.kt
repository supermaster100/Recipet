package com.example.myexpenses.data.db

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "Exchanges")
data class Exchange(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val dateOfExchange: Long,
    val amountSpent: String,
    val spentCurrency: String,
    val amountReceived: String,
    val receivedCurrency: String,
    val description: String,
    val photo: String = "",
    val export: Long = -1,
    val delPhoto: Boolean = false,
    val status: Boolean = true
)
