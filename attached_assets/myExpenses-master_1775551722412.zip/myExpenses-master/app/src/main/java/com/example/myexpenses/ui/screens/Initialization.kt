package com.example.myexpenses.ui.screens

import android.annotation.SuppressLint
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavController
import com.example.myexpenses.data.Helper
import com.example.myexpenses.data.Route
import com.example.myexpenses.data.db.Budget
import com.example.myexpenses.data.db.General
import com.example.myexpenses.ui.AppViewModelProvider
import com.example.myexpenses.ui.screens.models.BudgetModule
import com.example.myexpenses.ui.screens.models.GeneralModule
import com.example.myexpenses.ui.screens.more.GeneralDataSettings
import kotlinx.coroutines.launch

@SuppressLint("CoroutineCreationDuringComposition")
@Composable
fun Initialization (
    navController : NavController,
    generalModel: GeneralModule = viewModel(factory = AppViewModelProvider.Factory),
    budgetModel: BudgetModule = viewModel(factory = AppViewModelProvider.Factory)
){
    val currentDestination = navController.currentDestination?.route ?: ""


    val coroutineScope = rememberCoroutineScope()

    var editItem: List<General>? by remember { mutableStateOf(null) }
    var budgets: List<Budget>? by remember { mutableStateOf(null) }
    if (editItem == null) {
        coroutineScope.launch {
            editItem = generalModel.get()
        }
        return
    }
    if (budgets == null) {
        coroutineScope.launch {
            budgets = budgetModel.get()
        }
        return
    }

    if (editItem!!.isNotEmpty() && budgets!!.isNotEmpty())
        navController.navigate(Route.EXPENSES)
    else Scaffold(
        topBar = { Helper.TopBar(currentDestination) },
        bottomBar = {
            Helper.BottomBar(currentDestination) {}
        },
        containerColor = Helper.Color.Black,
        contentColor = Helper.Color.White
    ) {
        Column(
            modifier = Modifier
                .padding(it)
                .fillMaxSize()
        ) {
            GeneralDataSettings({
                if (!it) {
                    coroutineScope.launch {
                        budgets = budgetModel.get()
                        editItem = generalModel.get()
                    }
                }
            })
            /*Column(
                modifier = Modifier
                    .clip(shape = Helper.bRadius)
                    .background(Helper.Color.Black2C)
                    .padding(16.dp),
                verticalArrangement = Arrangement.Top
            ) {
                if (editItem!!.isEmpty()) {
                    Helper.TextH2(text = "General data")
                    Spacer(Modifier.size(16.dp))
                    GeneralEdit(
                        null,
                        saveChange = {
                            coroutineScope.launch {
                                generalModel.insert(it)
                                editItem = generalModel.get()

                            }
                        }
                    )
                } else {
                    Helper.TextH2(text = "Budget data")
                    Spacer(Modifier.size(16.dp))
                    BudgetEdit {
                        coroutineScope.launch {
                            budgetModel.insert(it)
                            budgets = budgetModel.get()
                        }
                    }
                }
            }*/
        }
    }
}
