package com.example.myexpenses.ui.screens.models

import androidx.lifecycle.ViewModel
import com.example.myexpenses.data.db.Budget
import com.example.myexpenses.data.db.ExpenseDao

class BudgetModule(private val expenseDao: ExpenseDao) : ViewModel() {
    suspend fun get(): List<Budget> {
        return expenseDao.getBudgets()
    }
    suspend fun insert(budget: Budget): Long {
        return expenseDao.insertBudget(budget)
    }
    suspend fun delete(id: Long) {
        expenseDao.deleteBudget(id)
    }
}