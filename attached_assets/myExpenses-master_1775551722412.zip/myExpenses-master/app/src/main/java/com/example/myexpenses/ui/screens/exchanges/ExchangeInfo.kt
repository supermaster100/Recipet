package com.example.myexpenses.ui.screens.exchanges

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.myexpenses.R
import com.example.myexpenses.data.Helper
import com.example.myexpenses.data.db.Exchange
import com.example.myexpenses.ui.AppViewModelProvider
import com.example.myexpenses.ui.components.ImageField
import com.example.myexpenses.ui.components.OwnTextMultiLineField
import com.example.myexpenses.ui.components.PhotoPopUp
import com.example.myexpenses.ui.screens.models.MediaStoreModel

@Composable
fun ExchangeInfo(
    exchange: Exchange,
    editExchange: (Exchange) -> Unit,
    viewMedia: MediaStoreModel = viewModel(factory = AppViewModelProvider.Factory)
) {
    val focusRequester = remember { FocusRequester() }
    var edit: Int by remember { mutableIntStateOf(0) }
    var editValue: String by remember { mutableStateOf("") }
    val resetEdit = {
        edit = 0
        editValue = ""
    }

    var popUpImage by remember { mutableStateOf(false) }
    if (popUpImage) PhotoPopUp(
        cancel = { popUpImage = false },
        changeImage = {
            editExchange(exchange.copy(
                photo = if (exchange.photo.isEmpty()) {
                    viewMedia.saveToLocal(it.toString())
                } else {
                    viewMedia.saveToLocal(it.toString(),exchange.photo)
                }
            ))
            popUpImage = false
        }
    )

    Column(
        modifier = Modifier
            .verticalScroll(rememberScrollState())
    ) {
        ImageField(
            currentUri = exchange.photo,
            popUpImage = { popUpImage = true },
            title = null
        )
        Spacer(Modifier.size(16.dp))
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .clip(Helper.bRadius)
                .background(Helper.Color.Black2C)
                .padding(16.dp)
        ) {
            Helper.TextH2(text = "General Info")
            Spacer(Modifier.size(16.dp))
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(Helper.bRadius)
                    .background(Helper.Color.Black3C)
                    .padding(16.dp)
            ) {
                Helper.TextH6("Exchange rate")
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Helper.Color.Black2C)
                        .clip(Helper.bRadius)
                        .padding(16.dp, 8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    var rTop by remember { mutableStateOf(true) }

                    Column(horizontalAlignment = Alignment.Start) {
                        Helper.TextH6(if (rTop) exchange.receivedCurrency else exchange.spentCurrency)
                        Helper.Text("1.00")
                    }
                    Icon(
                        modifier = Modifier
                            .clickable { rTop = !rTop }
                            .size(24.dp),
                        painter = painterResource(R.drawable.ico_change),
                        tint = if (rTop) Helper.Color.White else Helper.Color.Blue,
                        contentDescription = ""
                    )
                    Column(horizontalAlignment = Alignment.End) {
                        Helper.TextH6(if (rTop) exchange.spentCurrency else exchange.receivedCurrency)
                        Helper.Text(
                            "%.3f".format(
                                if (rTop)
                                    exchange.amountSpent.replace(',', '.')
                                        .toDouble() / exchange.amountReceived.replace(',', '.')
                                        .toDouble()
                                else
                                    exchange.amountReceived.replace(',', '.')
                                        .toDouble() / exchange.amountSpent.replace(',', '.')
                                        .toDouble()
                            )
                        )
                    }
                }
            }
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(Helper.bRadius)
                    .background(Helper.Color.Black3C)
                    .padding(16.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Column(horizontalAlignment = Alignment.Start) {
                        Helper.TextH6("Amount spent")
                        Helper.Text(
                            "${Helper.getCurrencySymbol(exchange.spentCurrency)}${Helper.formatDouble(exchange.amountSpent)}"
                        )
                    }
                    Text(text = "")
                    Column(horizontalAlignment = Alignment.End) {
                        Helper.TextH6("Currency")
                        Helper.Text(exchange.spentCurrency)
                    }
                }
                Helper.HDivider()
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Column(horizontalAlignment = Alignment.Start) {
                        Helper.TextH6("Amount received")
                        Helper.Text(
                            "${Helper.getCurrencySymbol(exchange.receivedCurrency)}${Helper.formatDouble(exchange.amountReceived)}"
                        )
                    }
                    Text(text = "")
                    Column(horizontalAlignment = Alignment.End) {
                        Helper.TextH6("Currency")
                        Helper.Text(exchange.receivedCurrency)
                    }
                }
                Helper.HDivider()
                Helper.TextH6("Date of exchange")
                Helper.Text(Helper.fData(exchange.dateOfExchange))
            }
            Spacer(Modifier.size(16.dp))
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(Helper.bRadius)
                    .background(Helper.Color.Black3C)
                    .padding(16.dp)
            ) {
                Helper.TextH6("Description")

                if (edit == 2) {
                    OwnTextMultiLineField(
                        modifier = Modifier.focusRequester(focusRequester),
                        value = editValue,
                        changeValue = { editValue = it },
                        label = null,
                        placeholder = "Enter you description here"
                    )
                    Helper.TextH6(
                        text = "Save",
                        modifier = Modifier
                            .drawBehind {
                                val strokeWidthPx = 1.dp.toPx()
                                val verticalOffset = size.height - 2.sp.toPx()
                                drawLine(
                                    color = Color(0xFFF3F3F3),
                                    strokeWidth = strokeWidthPx,
                                    start = Offset(0f, verticalOffset),
                                    end = Offset(size.width, verticalOffset)
                                )
                            }
                            .clickable {
                                editExchange(exchange.copy(description = editValue))
                                resetEdit()
                            }
                    )
                    LaunchedEffect(Unit) {
                        focusRequester.requestFocus()
                    }
                } else {
                    Helper.Text(exchange.description)
                    Helper.TextH6(
                        text = "Edit",
                        modifier = Modifier
                            .drawBehind {
                                val strokeWidthPx = 1.dp.toPx()
                                val verticalOffset = size.height - 2.sp.toPx()
                                drawLine(
                                    color = Color(0xFFF3F3F3),
                                    strokeWidth = strokeWidthPx,
                                    start = Offset(0f, verticalOffset),
                                    end = Offset(size.width, verticalOffset)
                                )
                            }
                            .clickable {
                                edit = 2
                                editValue = exchange.description
                            }
                    )
                }
            }
        }
    }
}