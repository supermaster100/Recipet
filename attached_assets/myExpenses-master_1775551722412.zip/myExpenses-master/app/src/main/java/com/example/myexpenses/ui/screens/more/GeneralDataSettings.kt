package com.example.myexpenses.ui.screens.more

import android.annotation.SuppressLint
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.myexpenses.R
import com.example.myexpenses.data.Helper
import com.example.myexpenses.data.db.Budget
import com.example.myexpenses.data.db.General
import com.example.myexpenses.nonScaledSp
import com.example.myexpenses.ui.AppViewModelProvider
import com.example.myexpenses.ui.components.UnsavedChanges
import com.example.myexpenses.ui.screens.models.BudgetModule
import com.example.myexpenses.ui.screens.models.GeneralModule
import kotlinx.coroutines.launch

@SuppressLint("CoroutineCreationDuringComposition")
@Composable
fun GeneralDataSettings(
    setEditMod: (Boolean) -> Unit,
    generalModel: GeneralModule = viewModel(factory = AppViewModelProvider.Factory),
    budgetModel: BudgetModule = viewModel(factory = AppViewModelProvider.Factory)
) {
    val coroutineScope = rememberCoroutineScope()

    var editItem: List<General>? by remember { mutableStateOf(null) }
    var budgets: List<Budget>? by remember { mutableStateOf(null) }

    var editGeneralMode: Boolean by remember { mutableStateOf(false) }
    var changeGeneralMode: Boolean by remember { mutableStateOf(false) }
    var addBudgetMode: Boolean by remember { mutableStateOf(false) }
    var changeBudgetMode: Boolean by remember { mutableStateOf(false) }


    var unsavedChanges by remember { mutableStateOf(false) }
    var unsavedChangesAct by remember { mutableStateOf("") }
    if (unsavedChanges) UnsavedChanges(
        back = {
            if (unsavedChangesAct == "General") {
                editGeneralMode = false
                changeGeneralMode = false
            } else if (unsavedChangesAct == "Budget"){
                addBudgetMode = false
                changeBudgetMode = false
            }

            setEditMod(changeGeneralMode||changeBudgetMode)
            unsavedChanges = false
            unsavedChangesAct = ""
        },
        dismiss = { unsavedChanges = false; unsavedChangesAct = "" }
    )

    if (editItem == null) {
        coroutineScope.launch {
            editItem = generalModel.get()
        }
        return
    }
    if (budgets == null) {
        coroutineScope.launch {
            budgets = budgetModel.get()
        }
        return
    }

    var confimBudgetDelete: Budget? by remember { mutableStateOf(null) }
    if (confimBudgetDelete != null) {
        ConfimBudgetDeletePopUp(
            budget = confimBudgetDelete!!,
            cancel = { confimBudgetDelete = null },
            confim = {
                coroutineScope.launch {
                    budgetModel.delete(confimBudgetDelete!!.id)
                    budgets = budgetModel.get()
                    confimBudgetDelete = null
                }
            }
        )
    }

    Column(
        modifier = Modifier
            .padding(16.dp)
            .verticalScroll(rememberScrollState())
    ) {
        Column(
            modifier = Modifier
                .clip(shape = Helper.bRadius)
                .background(Helper.Color.Black2C)
                .padding(16.dp),
            verticalArrangement = Arrangement.Top
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Helper.TextH2(text = "General data")
                Spacer(Modifier.weight(1f))
                IconButton(onClick = {
                    if (editGeneralMode && changeGeneralMode) {
                        unsavedChanges = true
                        unsavedChangesAct = "General"
                    } else if (editGeneralMode){
                        editGeneralMode = false
                    } else {
                        editGeneralMode = true
                    }
                }) {
                    Icon(
                        painter = painterResource(if (editGeneralMode) R.drawable.ico_close else R.drawable.ico_pencil),
                        tint = Helper.Color.White,
                        contentDescription = ""
                    )
                }
            }
            if (editGeneralMode) {
                GeneralEdit(
                    editItem,
                    alreadyChange = {
                        changeGeneralMode = true
                        setEditMod(true)
                                    },
                    saveChange = {
                        coroutineScope.launch {
                            if (editItem!!.isNotEmpty()) {
                                generalModel.update(it)
                            } else {
                                generalModel.insert(it)
                            }
                            editItem = generalModel.get()
                            editGeneralMode = false
                            changeGeneralMode = false
                            setEditMod(changeBudgetMode)
                        }
                    }
                )
            } else {
                Helper.TextH6("Worker number")
                Helper.Text(if (editItem!!.isEmpty()) "None" else editItem!![0].workerNumber)
                Helper.HDivider()
                Helper.TextH6("Department")
                Helper.Text(if (editItem!!.isEmpty()) "None" else editItem!![0].department)
                Helper.HDivider()
                Helper.TextH6("Month / Year")
                Helper.Text(text = if (editItem!!.isEmpty()) "None" else editItem!![0].monthYear)
            }
        }
        Spacer(Modifier.size(12.dp))
        Column(
            modifier = Modifier
                .clip(shape = Helper.bRadius)
                .background(Helper.Color.Black2C)
                .padding(16.dp),
            verticalArrangement = Arrangement.Top
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    modifier = Modifier.weight(1f),
                    text = "Budget numbers",
                    color = Color(0xFFF3F3F3),
                    fontSize = 20.sp.nonScaledSp,
                    fontWeight = FontWeight(700)
                )
                IconButton(onClick = {
                    if (addBudgetMode && changeBudgetMode) {
                        unsavedChanges = true
                        unsavedChangesAct = "Budget"
                    } else if (addBudgetMode){
                        addBudgetMode = false
                    } else {
                        addBudgetMode = true
                    }
                }) {
                    Icon(
                        painter = painterResource(if (addBudgetMode) R.drawable.ico_close else R.drawable.ico_add),
                        tint = Helper.Color.White,
                        contentDescription = ""
                    )
                }
            }
            Spacer(Modifier.size(16.dp))
            if (addBudgetMode) {
                BudgetEdit(
                    alreadyChange = {
                        changeBudgetMode = true
                        setEditMod(true)
                    },
                    saveChange = {
                        coroutineScope.launch {
                            budgetModel.insert(it)
                            budgets = budgetModel.get()
                            addBudgetMode = false
                            changeBudgetMode = false
                            setEditMod(changeGeneralMode)
                        }
                    }
                )
            } else {
                budgets!!.forEach {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(shape = Helper.bRadius)
                            .background(Helper.Color.Black3C)
                            .padding(8.dp, 12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(
                            modifier = Modifier.fillMaxWidth(0.85f)
                        ){
                            Helper.TextH6(it.budgetNumberName)
                            Helper.Text(it.budgetNumber)
                        }
                        IconButton(onClick = { confimBudgetDelete = it }) {
                            Icon(
                                painter = painterResource(R.drawable.ico_basket),
                                tint = Helper.Color.White50,
                                contentDescription = ""
                            )
                        }
                    }
                    Spacer(Modifier.size(8.dp))
                }
            }
        }
    }
}