package com.example.myexpenses.ui.screens

import android.annotation.SuppressLint
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.Icon
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.core.net.toUri
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavController
import coil.compose.rememberImagePainter
import com.example.myexpenses.R
import com.example.myexpenses.data.Helper
import com.example.myexpenses.data.Route
import com.example.myexpenses.data.db.Receipt
import com.example.myexpenses.ui.AppViewModelProvider
import com.example.myexpenses.ui.components.Await
import com.example.myexpenses.ui.components.EmptyList
import com.example.myexpenses.ui.screens.expenses.ExpensesInfo
import com.example.myexpenses.ui.screens.models.AddReceiptModule
import com.example.myexpenses.ui.screens.models.MediaStoreModel
import kotlinx.coroutines.launch
import java.io.File

@SuppressLint("MutableCollectionMutableState", "CoroutineCreationDuringComposition")
@Composable
fun Expenses(
    navController: NavController,
    expensesModel: AddReceiptModule = viewModel(factory = AppViewModelProvider.Factory),
    viewMedia: MediaStoreModel = viewModel(factory = AppViewModelProvider.Factory)
) {

    val coroutineScope = rememberCoroutineScope()
    var mainList_: List<Receipt>? by remember { mutableStateOf(null) }

    var openFilter: Boolean by remember { mutableStateOf(false) }
    var typeFilter: List<String> by remember { mutableStateOf(listOf()) }

    var moreInfo: Int by remember { mutableIntStateOf(-1) }

    if (mainList_ == null) {
        coroutineScope.launch {
            mainList_ = expensesModel.getAll()
        }
        Await()
        return
    }

    val mainList = mainList_!!.filter{ typeFilter.isEmpty() || typeFilter.contains(it.expensesType) }

    val currentDestination = navController.currentDestination?.route ?: ""

    Scaffold(
        topBar = {
            if (moreInfo != -1)
                Helper.TopBar(
                    "Receipt",
                    {moreInfo = -1}
                )
            else if (mainList_!!.isNotEmpty()) {
                Helper.TopBar(
                    currentDestination,
                    rIcon = {
                        Icon(
                            modifier = Modifier.clickable { openFilter = !openFilter },
                            painter = painterResource(
                                if (typeFilter.isEmpty())
                                    R.drawable.ico_filter
                                else
                                    R.drawable.ico_filter_on
                            ),
                            contentDescription = "",
                            tint = if (typeFilter.isEmpty())
                                Helper.Color.White
                            else
                                Helper.Color.Blue


                        )
                    }
                )
            } else {
                Helper.TopBar(currentDestination)
            }
        },
        bottomBar = { Helper.BottomBar(currentDestination) { navController.navigate(it) } },
        containerColor = Helper.Color.Black,
        contentColor = Helper.Color.White
    ) {
        Column(
            modifier = Modifier
                .padding(it)
                .fillMaxSize()
        ) {
            if (openFilter){
                Helper.TextH6(text = "Type (Multiple Choice)")
                Row(
                    modifier = Modifier.fillMaxSize().horizontalScroll(rememberScrollState())
                ){
                    if ( typeFilter.isEmpty() ){
                        Helper.ButtonBlue(
                            onClick = {},
                            text = { Helper.Text("All") },
                            modifier = Modifier
                        )
                    } else {
                        Helper.ButtonGrey(
                            modifier = Modifier,
                            onClick = { typeFilter = listOf() },
                            text = { Helper.Text("All") }
                        )
                    }
                    Spacer(Modifier.size(16.dp))
                    Helper.receiptTypes.forEach { type ->
                        if ( typeFilter.contains(type) ){
                            Helper.ButtonBlue(
                                onClick = {
                                    val ind = typeFilter.indexOf(type)
                                    typeFilter = typeFilter.subList(0, ind) + typeFilter.subList(ind + 1, typeFilter.size)
                                },
                                text = { Helper.Text(type) },
                                modifier = Modifier
                            )
                        } else {
                            Helper.ButtonGrey(
                                modifier = Modifier,
                                onClick = { typeFilter += type },
                                text = { Helper.Text(type) }
                            )
                        }
                        Spacer(Modifier.size(16.dp))
                    }
                }
            } else if (mainList_!!.isEmpty()) {
                EmptyList(
                    ico = painterResource(R.drawable.ico_expenses_screen),
                    text1 = "Expenses are empty",
                    text2 = "You can start adding receipts to track your expenses",
                    textButton = "Add Receipt",
                    clickButton = { navController.navigate(Route.ADD_RECEIPT) }
                )
            } else if (moreInfo != -1) {
                ExpensesInfo(
                    receipt = mainList[moreInfo],
                    editExchange = {
                        coroutineScope.launch {
                            expensesModel.update(it)
                            mainList_ = expensesModel.getAll()
                        }
                    }
                )
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize()
                ) {
                    items(mainList.count()) { indexItem ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp, 12.dp)
                                .clickable {
                                    moreInfo = indexItem
                                },
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row {
                                if (mainList[indexItem].photo.isEmpty()) {
                                    Column(
                                        verticalArrangement = Arrangement.Center,
                                        horizontalAlignment = Alignment.CenterHorizontally,
                                        modifier = Modifier
                                            .width(48.dp)
                                            .height(48.dp)
                                            .clip(Helper.bRadius)
                                            .background(Helper.Color.Black2C)
                                    ) {
                                        Icon(
                                            modifier = Modifier.size(30.dp),
                                            painter = painterResource(R.drawable.ico_expense),
                                            contentDescription = "",
                                            tint = Helper.Color.White50
                                        )
                                    }
                                } else {
                                    Image(
                                        painter = rememberImagePainter(File(mainList[indexItem].photo).toUri()),
                                        contentDescription = null,
                                        contentScale = ContentScale.Crop,
                                        modifier = Modifier
                                            .width(48.dp)
                                            .height(48.dp)
                                            .clip(Helper.bRadius)
                                    )
                                }
                                Spacer(Modifier.size(16.dp))
                                Column(
                                    verticalArrangement = Arrangement.SpaceBetween,
                                    modifier = Modifier.height(48.dp)
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Helper.Text(mainList[indexItem].expensesType)
                                        if (mainList[indexItem].photo.isEmpty()) {
                                            Spacer(Modifier.size(16.dp))
                                            Icon(
                                                painter = painterResource(R.drawable.ico_no_photo),
                                                contentDescription = ""
                                            )
                                        }
                                    }
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Helper.TextH6(Helper.fData(mainList[indexItem].payingDate))
                                        Spacer(Modifier.size(8.dp))
                                        Icon(
                                            painter = painterResource(R.drawable.ico_dote),
                                            contentDescription = "",
                                            tint = Helper.Color.White70
                                        )
                                        Spacer(Modifier.size(8.dp))
                                        Helper.TextH6(viewMedia.getImageDate(mainList[indexItem].photo))
                                    }
                                }
                            }
                            Row(
                                verticalAlignment = Alignment.Bottom
                            ) {
                                val f = mainList[indexItem].amount.replace(",",".").split(".")
                                Helper.Text(text = f[0])
                                Helper.TextH6(
                                    text = ".${f[1]}",
                                    modifier = Modifier.padding(bottom = 2.dp)
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}