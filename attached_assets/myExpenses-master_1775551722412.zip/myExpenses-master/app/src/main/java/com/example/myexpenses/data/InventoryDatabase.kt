package com.example.myexpenses.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.myexpenses.R
import com.example.myexpenses.data.db.Budget
import com.example.myexpenses.data.db.Exchange
import com.example.myexpenses.data.db.ExpenseDao
import com.example.myexpenses.data.db.General
import com.example.myexpenses.data.db.Leg
import com.example.myexpenses.data.db.Receipt
import com.example.myexpenses.data.db.Travel

@Database(
    entities = [General::class, Exchange::class, Budget::class, Receipt::class, Leg::class, Travel::class],
    version = 32, exportSchema = false
)
abstract class InventoryDatabase : RoomDatabase() {
    abstract fun itemDao(): ExpenseDao
    companion object {
        @Volatile
        private var Instance: InventoryDatabase? = null
        fun getDatabase(context: Context): InventoryDatabase {
            return Instance ?: synchronized(this) {
                Room.databaseBuilder(
                    context,
                    InventoryDatabase::class.java,
                    context.resources.getString(R.string.db_name)
                )
                    .fallbackToDestructiveMigration()
                    .build()
                    .also { Instance = it }
            }
        }
    }
}
