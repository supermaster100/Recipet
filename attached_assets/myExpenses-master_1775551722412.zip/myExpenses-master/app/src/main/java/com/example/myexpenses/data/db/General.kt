package com.example.myexpenses.data.db

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "Generals")
data class General(
    @PrimaryKey(autoGenerate = true)
    val id: Int = 0,
    val workerNumber: String,
    val monthYear: String,
    val department: String,
)