package com.example.myexpenses.ui.screens.models

import androidx.lifecycle.ViewModel
import com.example.myexpenses.data.db.Exchange
import com.example.myexpenses.data.db.ExpenseDao

class AddExchangeModule(private val expenseDao: ExpenseDao) : ViewModel() {
    suspend fun insert(exchange: Exchange) {
        expenseDao.insertExchange(exchange)
    }
    fun get(id: Long): Exchange {
        return expenseDao.getExchange(id)
    }

    suspend fun getAll(): List<Exchange> {
        return expenseDao.getExchanges()
    }
    suspend fun update(exchange: Exchange) {
        expenseDao.updateExchange(exchange)
    }
}