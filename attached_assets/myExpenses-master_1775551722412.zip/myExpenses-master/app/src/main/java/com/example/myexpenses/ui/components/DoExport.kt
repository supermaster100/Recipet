package com.example.myexpenses.ui.components

import android.annotation.SuppressLint
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.myexpenses.data.db.Exchange
import com.example.myexpenses.data.db.General
import com.example.myexpenses.data.db.Leg
import com.example.myexpenses.data.db.Receipt
import com.example.myexpenses.data.db.Travel
import com.example.myexpenses.ui.AppViewModelProvider
import com.example.myexpenses.ui.screens.models.DownloadReportModule
import com.example.myexpenses.ui.screens.models.MediaStoreModel
import kotlinx.coroutines.launch

@SuppressLint("CoroutineCreationDuringComposition")
@Composable
fun DoExport(
    exportModel: DownloadReportModule = viewModel(factory = AppViewModelProvider.Factory),
    viewMedia: MediaStoreModel = viewModel(factory = AppViewModelProvider.Factory),
    endExport: (String)->Unit = {},
) {
    val coroutineScope = rememberCoroutineScope()
    var receipts: List<Receipt>? by remember { mutableStateOf(null) }
    if (receipts == null) {
        coroutineScope.launch {
            receipts = exportModel.getReceipts()
        }
        return
    }

    var exchanges: List<Exchange>? by remember { mutableStateOf(null) }
    if (exchanges == null) {
        coroutineScope.launch {
            exchanges = exportModel.getExchanges()
        }
        return
    }

    var legs: List<Leg>? by remember { mutableStateOf(null) }
    var travels: List<Travel>? by remember { mutableStateOf(null) }
    if (legs == null){
        coroutineScope.launch{
            legs = exportModel.getLeg()
        }
        return
    }
    if (legs!!.isNotEmpty()) {
        if (travels == null) {
            coroutineScope.launch {
                travels = exportModel.getTravels(legs!![0].id)
            }
            return
        }
    }

    var general: List<General>? by remember { mutableStateOf(null) }
    if (general == null) {
        coroutineScope.launch {
            general = exportModel.getGeneral()
        }
        return
    }
    val exportLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocumentTree(),
        onResult = { uri ->
            val exFolder = viewMedia.doExport(
                uri,
                general!![0],
                travels,
                receipts!!,
                exchanges!!
            )
            if ( exFolder != "Error" ) {
                coroutineScope.launch {
                    val now = System.currentTimeMillis()
                    exportModel.deleteReceipts(now)
                    exportModel.deleteExchanges(now)
                    if ( ! legs.isNullOrEmpty() ) {
                        val k = legs!![0].copy(status = false)
                        exportModel.updateTravels(legs!![0].id, now)
                    }
                    endExport(exFolder)
                }
            } else {
                endExport(exFolder)
            }
        }
    )
    coroutineScope.launch() {
        exportLauncher.launch(null)
    }
}