package com.example.myexpenses.ui.screens.more

import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.myexpenses.data.Helper
import com.example.myexpenses.data.db.General
import com.example.myexpenses.ui.components.OwnTextField

@Composable
fun GeneralEdit(
    editItem: List<General>?,
    alreadyChange: () -> Unit = {},
    saveChange: (General) -> Unit
) {
    val values = object {
        var workerNumber: String by remember { mutableStateOf(if (!editItem.isNullOrEmpty()) editItem[0].workerNumber else "") }
        var monthYear: String by remember { mutableStateOf(if (!editItem.isNullOrEmpty()) editItem[0].monthYear else "") }
        var department: String by remember { mutableStateOf(if (!editItem.isNullOrEmpty()) editItem[0].department else "") }

        fun saveChange() {
            val id = if (!editItem.isNullOrEmpty()) editItem[0].id else 0
            saveChange(
                General(
                    id = id,
                    workerNumber = this.workerNumber,
                    monthYear = this.monthYear,
                    department = this.department
                )
            )
        }
    }

    val errorM = object {
        var workerNumber: Boolean by remember { mutableStateOf(false) }
        var monthYear: Boolean by remember { mutableStateOf(false) }
        var department: Boolean by remember { mutableStateOf(false) }
        var hasError: Boolean by remember { mutableStateOf(false) }
    }
    val setError = fun(): Boolean {
        errorM.workerNumber = values.workerNumber.isEmpty()
        errorM.monthYear = values.monthYear.isEmpty()
        errorM.department = values.department.isEmpty()

        return errorM.workerNumber || errorM.monthYear || errorM.department
    }
    if (errorM.hasError) {
        errorM.hasError = setError()
    }

    OwnTextField(
        value = values.workerNumber,
        label = "Worker number",
        changeValue = {
            alreadyChange()
            values.workerNumber = it
                      },
        isError = errorM.workerNumber,
        errorText = "Please enter the worker number",
        type = "Int"
    )
    Spacer(Modifier.size(12.dp))
    OwnTextField(
        value = values.department,
        label = "Department",
        changeValue = {
            alreadyChange()
            values.department = it
                      },
        isError = errorM.department,
        errorText = "Please enter the department",
    )
    Spacer(Modifier.size(12.dp))
    MonthYearField(
        value = values.monthYear,
        changeValue = {
            alreadyChange()
            values.monthYear = it
                      },
        isError = errorM.monthYear
    )
    Spacer(Modifier.size(20.dp))
    Helper.ButtonBlue(
        onClick = {
            errorM.hasError = setError()
            if (!errorM.hasError) {
                values.saveChange()
            }
        },
        text = { Helper.Text("Save changes") })
}