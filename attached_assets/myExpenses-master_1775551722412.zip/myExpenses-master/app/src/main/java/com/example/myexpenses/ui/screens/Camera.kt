package com.example.myexpenses.ui.screens

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageCapture
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.MutableState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.viewmodel.compose.viewModel
import coil.compose.rememberImagePainter
import com.example.myexpenses.R
import com.example.myexpenses.data.Helper
import com.example.myexpenses.ui.AppViewModelProvider
import com.example.myexpenses.ui.screens.models.MediaStoreModel
import com.google.accompanist.permissions.ExperimentalPermissionsApi
import com.google.accompanist.permissions.PermissionsRequired
import com.google.accompanist.permissions.rememberMultiplePermissionsState
import kotlinx.coroutines.launch
import kotlin.coroutines.resume
import kotlin.coroutines.suspendCoroutine


@OptIn(ExperimentalPermissionsApi::class)
@SuppressLint("SimpleDateFormat")
@Composable
fun CameraScreen(
    cancel: () -> Unit = {},
    returnUri: (Uri) -> Unit = {},
    viewMedia: MediaStoreModel = viewModel(factory = AppViewModelProvider.Factory)
) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current

    val previewView: PreviewView = remember { PreviewView(context) }
    val imageCapture: ImageCapture = remember { ImageCapture.Builder().build() }
    val cameraSelector: MutableState<CameraSelector> =
        remember { mutableStateOf(CameraSelector.DEFAULT_BACK_CAMERA) }

    val permissionState =
        rememberMultiplePermissionsState(permissions = listOf(Manifest.permission.CAMERA))
    var photoUri: Uri? by remember { mutableStateOf(null) }

    fun changeCameraSelector() {
        cameraSelector.value =
            if (cameraSelector.value == CameraSelector.DEFAULT_BACK_CAMERA) CameraSelector.DEFAULT_FRONT_CAMERA
            else CameraSelector.DEFAULT_BACK_CAMERA

        lifecycleOwner.lifecycleScope.launch {
            createPhotoCaptureUseCase(
                context = context,
                lifecycleOwner = lifecycleOwner,
                cameraSelector = cameraSelector.value,
                previewView = previewView,
                imageCapture = imageCapture
            )
        }
    }

    LaunchedEffect(Unit) {
        permissionState.launchMultiplePermissionRequest()
    }

    LaunchedEffect(previewView) {
        createPhotoCaptureUseCase(
            context = context,
            lifecycleOwner = lifecycleOwner,
            cameraSelector = cameraSelector.value,
            previewView = previewView,
            imageCapture = imageCapture
        )
    }

    PermissionsRequired(
        multiplePermissionsState = permissionState,
        permissionsNotGrantedContent = {
            LaunchedEffect(Unit) {
                permissionState.launchMultiplePermissionRequest()
            }
        },
        permissionsNotAvailableContent = {
            Column(
                modifier = Helper.modifierAlert,
                verticalArrangement = Arrangement.Center,
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Helper.TextH2(text = "You must set permission to the camera.")
                Helper.ButtonBlue(
                    onClick = { openAppSettings(context) },
                    text = { Helper.Text(text = "Settings") })
                Spacer(Modifier.size(5.dp))
                Helper.ButtonGrey(onClick = { cancel() }, text = { Helper.Text(text = "Cancel") })
            }
        }
    ) {
        Scaffold(
            topBar = {
                Row(
                    modifier = Modifier.fillMaxWidth().background(Helper.Color.Black)
                        .padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton( modifier = Modifier.padding(end = 12.dp), onClick = { cancel() } ) {
                        Icon(
                            tint = Helper.Color.White,
                            modifier = Modifier.size(16.dp),
                            painter = painterResource(R.drawable.ico_row_left),
                            contentDescription = ""
                        )
                    }
                    Helper.TextH1(text = "Camera")
                }
            },
            floatingActionButton = {
                if (photoUri == null) {
                    FloatingActionButton(
                        onClick = { changeCameraSelector() },
                        containerColor = Helper.Color.Black3C
                    ) {
                        Icon(
                            tint = Helper.Color.White,
                            modifier = Modifier.size(24.dp),
                            painter = painterResource(R.drawable.ico_change),
                            contentDescription = ""
                        )
                    }
                }
            },
            bottomBar = {
                Row(
                    modifier = Modifier.fillMaxWidth().height(100.dp).background(Helper.Color.Black0E),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center
                ) {
                    Image(
                        modifier = Modifier
                            .size(76.dp)
                            .clickable {
                                if (photoUri == null) {
                                    viewMedia.takePicture(imageCapture) {
                                        photoUri = it
                                    }
                                } else {
                                    returnUri(photoUri!!)
                                }
                            },
                        painter = painterResource(if (photoUri == null) R.drawable.ico_make_photo else R.drawable.ico_take_photo),
                        contentDescription = ""
                    )

                }
                if (photoUri != null) {
                    Row(
                        modifier = Modifier.height(100.dp).padding(start = 16.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Start
                    ) {
                        IconButton(
                            modifier = Modifier.size(32.dp),
                            onClick = {
                                viewMedia.deletePhoto(photoUri!!)
                                photoUri = null
                            }
                        ) {
                            Icon(
                                tint = Helper.Color.Red,
                                modifier = Modifier.size(32.dp),
                                painter = painterResource(R.drawable.ico_basket),
                                contentDescription = ""
                            )
                        }
                    }
                }
            }
        ) {
            if (photoUri == null) {
                AndroidView(
                    factory = { previewView },
                    modifier = Modifier
                        .padding(it)
                        .fillMaxSize()
                )
            } else {
                Image(
                    painter = rememberImagePainter(photoUri),
                    contentDescription = null,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
            }
        }
    }
}
suspend fun createPhotoCaptureUseCase(
    context: Context,
    lifecycleOwner: LifecycleOwner,
    cameraSelector: CameraSelector,
    previewView: PreviewView,
    imageCapture: ImageCapture
) {
    val preview = Preview.Builder()
        .build()
        .apply { setSurfaceProvider(previewView.surfaceProvider) }


    val cameraProvider = getCameraProvider(context)
    cameraProvider.unbindAll()
    cameraProvider.bindToLifecycle(
        lifecycleOwner,
        cameraSelector,
        preview,
        imageCapture
    )
}
fun openAppSettings(context: Context) {
    val packageName = context.packageName
    val intent = Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
    val uri = Uri.fromParts("package", packageName, null)
    intent.data = uri
    context.startActivity(intent)
}
suspend fun getCameraProvider(context: Context): ProcessCameraProvider = suspendCoroutine { continuation ->
    ProcessCameraProvider.getInstance(context).also { future ->
        future.addListener(
            {
                continuation.resume(future.get())
            },
            context.mainExecutor
        )
    }
}
