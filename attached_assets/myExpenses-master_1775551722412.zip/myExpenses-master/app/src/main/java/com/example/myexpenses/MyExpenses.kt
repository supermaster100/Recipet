package com.example.myexpenses

import android.annotation.SuppressLint
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.sp
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.myexpenses.data.Route
import com.example.myexpenses.ui.screens.AddReceipt
import com.example.myexpenses.ui.screens.Exchanges
import com.example.myexpenses.ui.screens.Expenses
import com.example.myexpenses.ui.screens.Initialization
import com.example.myexpenses.ui.screens.More
import com.example.myexpenses.ui.screens.Travel


class MyExpenses : ComponentActivity() {
    @SuppressLint("CoroutineCreationDuringComposition")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(
                colorScheme = darkColorScheme()
            ) {
                val navController = rememberNavController()
                NavHost(
                    navController = navController,
                    startDestination = Route.FIRST
                ) {
                    composable(Route.FIRST) {
                        Initialization(navController = navController)
                    }
                    composable(Route.EXPENSES) {
                        Expenses(navController = navController)
                    }
                    composable(Route.ADD_RECEIPT) {
                        AddReceipt(navController = navController)
                    }
                    composable(Route.TRAVEL) {
                        Travel(navController = navController)
                    }
                    composable(Route.ADD_TRAVEL) {
                        Travel(navController = navController, add = true)
                    }
                    composable(Route.EXCHANGES) {
                        Exchanges(navController = navController)
                    }
                    composable(Route.ADD_EXCHANGES) {
                        Exchanges(navController = navController, add = true)
                    }
                    composable(Route.MORE) {
                        More(navController = navController)
                    }
                }
            }
        }
    }
}
val TextUnit.nonScaledSp
    @Composable
    get() = (this.value / LocalDensity.current.fontScale).sp