package com.example.myexpenses.ui.screens.models

import androidx.lifecycle.ViewModel
import com.example.myexpenses.data.db.Budget
import com.example.myexpenses.data.db.ExpenseDao
import com.example.myexpenses.data.db.General
import com.example.myexpenses.data.db.Leg
import com.example.myexpenses.data.db.Travel

class AddTravelModule(private val expenseDao: ExpenseDao) : ViewModel() {
    suspend fun insertLeg(leg: Leg):Long {
        return expenseDao.insertLeg(leg)
    }
    suspend fun getLeg():List<Leg> {
        return expenseDao.getLegs()
    }
    suspend fun get(lId: Long): List<Travel> {
        return expenseDao.getTravels(lId)
    }
    suspend fun insert(travels: List<Travel>) {
        expenseDao.insertTravels(travels)
    }
    suspend fun update(travel: Travel) {
        expenseDao.updateTravel(travel)
    }
    suspend fun getBudgets(): List<Budget> {
        return expenseDao.getBudgets()
    }
    suspend fun getGeneral(): List<General> {
        return expenseDao.getGeneral()
    }
}