package com.example.myexpenses.ui.screens

import android.annotation.SuppressLint
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.Icon
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.core.net.toUri
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavController
import coil.compose.rememberImagePainter
import com.example.myexpenses.R
import com.example.myexpenses.data.Helper
import com.example.myexpenses.data.db.Exchange
import com.example.myexpenses.ui.AppViewModelProvider
import com.example.myexpenses.ui.components.Await
import com.example.myexpenses.ui.components.EmptyList
import com.example.myexpenses.ui.components.UnsavedChanges
import com.example.myexpenses.ui.screens.exchanges.AddExchange
import com.example.myexpenses.ui.screens.exchanges.ExchangeInfo
import com.example.myexpenses.ui.screens.models.AddExchangeModule
import kotlinx.coroutines.launch
import java.io.File

@SuppressLint("MutableCollectionMutableState", "CoroutineCreationDuringComposition",
    "SimpleDateFormat"
)
@Composable
fun Exchanges(
    navController: NavController,
    add: Boolean = false,
    exchangeModel: AddExchangeModule = viewModel(factory = AppViewModelProvider.Factory),
) {

    val coroutineScope = rememberCoroutineScope()
    var mainList: List<Exchange>? by remember { mutableStateOf(null) }
    var moreInfo: Int by remember { mutableIntStateOf(-1) }
    var addExchangeMod by remember { mutableStateOf(add) }

    if (mainList == null) {
        coroutineScope.launch {
            mainList = exchangeModel.getAll()
        }
        Await()
        return
    }

    var alreadyChange by remember { mutableStateOf(false) }
    var unsavedChanges by remember { mutableStateOf(false) }
    var unsavedChangesAct by remember { mutableStateOf("") }
    if (unsavedChanges) UnsavedChanges(
        back = {
            if (unsavedChangesAct == "Back") {
                addExchangeMod = false
            } else {
                navController.navigate(unsavedChangesAct)
            }
            unsavedChanges = false
            unsavedChangesAct = ""
        },
        dismiss = { unsavedChanges = false; unsavedChangesAct = "" }
    )


    val currentDestination = navController.currentDestination?.route ?: ""

    Scaffold(
        topBar = {
            if (addExchangeMod){
                Helper.TopBar(
                    "Add Exchange",
                    {
                        if (alreadyChange){
                            unsavedChanges = true
                            unsavedChangesAct = "Back"
                        } else {
                            addExchangeMod = false
                        }
                    }
                )
            } else if (moreInfo != -1) {
                Helper.TopBar("Exchange", {moreInfo=-1})
            } else if (mainList!!.isNotEmpty()){
                Helper.TopBar(currentDestination,
                    rIcon = {
                        Icon(
                            modifier = Modifier.clickable { addExchangeMod = true },
                            painter = painterResource(R.drawable.ico_add),
                            contentDescription = "",
                            tint = Helper.Color.White
                        )
                    })
            } else {
                Helper.TopBar(currentDestination)
            }
        },
        bottomBar = {
            Helper.BottomBar(currentDestination) {
                if (addExchangeMod && alreadyChange) {
                    unsavedChanges = true
                    unsavedChangesAct = it
                } else
                    navController.navigate(it)
            }
        },
        containerColor = Helper.Color.Black,
        contentColor = Helper.Color.White
    ) {
        Column(
            modifier = Modifier
                .padding(it)
                .fillMaxSize()
        ) {
            if (addExchangeMod) {
                AddExchange(
                    navController,
                    alreadyChange = { alreadyChange = true }
                )
            } else if (mainList!!.isEmpty()) {
                EmptyList(
                    ico = painterResource(R.drawable.ico_exchanges_screen),
                    text1 = "You don’t have any exchanges yet",
                    text2 = "",
                    textButton = "Add Exchange",
                    clickButton = { addExchangeMod = true }
                )
            } else if (moreInfo != -1) {
                ExchangeInfo(
                    exchange = mainList!![moreInfo],
                    editExchange = {
                        coroutineScope.launch {
                            exchangeModel.update(it)
                            mainList = exchangeModel.getAll()
                        }
                    }
                )
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    content = {
                        items(mainList!!.count()) { indexItem ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(16.dp, 0.dp)
                                    .clickable {
                                        moreInfo = indexItem
                                    },
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.Top
                            ) {
                                Row {
                                    if (mainList!![indexItem].photo.isEmpty()) {
                                        Column(
                                            verticalArrangement = Arrangement.Center,
                                            horizontalAlignment = Alignment.CenterHorizontally,
                                            modifier = Modifier
                                                .width(56.dp)
                                                .height(88.dp)
                                                .clip(Helper.bRadius)
                                                .background(Helper.Color.Black2C)
                                        ) {
                                            Icon(
                                                modifier = Modifier.size(32.dp),
                                                painter = painterResource(R.drawable.ico_exchanges_screen),
                                                contentDescription = "",
                                                tint = Helper.Color.Black3C
                                            )
                                        }
                                    } else {
                                        Image(
                                            painter = rememberImagePainter(File(mainList!![indexItem].photo).toUri()),
                                            contentDescription = null,
                                            contentScale = ContentScale.Crop,
                                            modifier = Modifier
                                                .width(56.dp)
                                                .height(88.dp)
                                                .clip(Helper.bRadius)
                                        )
                                    }
                                    Spacer(Modifier.size(16.dp))
                                    Column(
                                        verticalArrangement = Arrangement.SpaceBetween,
                                        modifier = Modifier.height(88.dp)
                                    ) {
                                        Helper.Text("Exchange")
                                        Text("")
                                        Column {
                                            Helper.Text(Helper.fData(mainList!![indexItem].dateOfExchange))
                                            Helper.Text("---")
                                        }
                                    }
                                }
                                Text("")
                                Column(
                                    verticalArrangement = Arrangement.SpaceBetween,
                                    horizontalAlignment = Alignment.End,
                                    modifier = Modifier.height(88.dp)
                                ) {
                                    Column(
                                        horizontalAlignment = Alignment.End,
                                    ) {
                                        Helper.TextH6(text = "${mainList!![indexItem].spentCurrency}/ Spent")
                                        Helper.Text(text = mainList!![indexItem].amountSpent)
                                    }
                                    Column(
                                        horizontalAlignment = Alignment.End,
                                    ) {
                                        Helper.TextH6(text = "${mainList!![indexItem].receivedCurrency}/ Recived")
                                        Helper.Text(text = mainList!![indexItem].amountReceived)
                                    }
                                }
                            }
                            if (mainList!!.count() - 1 != indexItem) Helper.HDivider()
                        }
                    }
                )
            }
        }
    }
}