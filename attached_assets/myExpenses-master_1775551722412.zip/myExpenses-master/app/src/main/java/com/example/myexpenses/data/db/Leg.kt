package com.example.myexpenses.data.db

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "Legs")
data class Leg(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val type: String,
    val status: Boolean = true,
)
