package com.example.myexpenses.ui.components

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults.buttonColors
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.painter.Painter
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.myexpenses.R
import com.example.myexpenses.data.Helper
import com.example.myexpenses.nonScaledSp

@Composable
fun EmptyList(
    ico: Painter,
    text1: String,
    text2: String,
    textButton: String = "",
    clickButton: (() -> Unit)? = null,
    customButton: @Composable (() -> Unit)? = null
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(start = 44.5.dp, end = 44.5.dp)
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(
            modifier = Modifier
                .size(112.dp)
                .padding(bottom = 24.dp),
            tint = Helper.Color.White,
            painter = ico,
            contentDescription = ""
        )
        Text(
            modifier = Modifier.padding(bottom = 16.dp),
            text = text1,
            textAlign = TextAlign.Center,
            color = Helper.Color.White,
            fontSize = 28.sp.nonScaledSp,
            lineHeight = 36.sp.nonScaledSp,
            fontWeight = FontWeight(700)
        )
        if (text2.isNotEmpty()) {
            Text(
                modifier = Modifier.padding(bottom = 48.dp),
                text = text2,
                textAlign = TextAlign.Center,
                color = Color(0xFFF3F3F3),
                fontSize = 20.sp.nonScaledSp,
                lineHeight = 28.sp.nonScaledSp,
                fontWeight = FontWeight(400)
            )
        } else {
            Spacer(Modifier.size(40.dp))
        }
        if (clickButton != null) {
            Button(
                modifier = Modifier.padding(20.dp, 8.dp),
                shape = Helper.bRadius,
                colors = buttonColors(
                    containerColor = Helper.Color.White,
                    contentColor = Helper.Color.Black,
                    disabledContainerColor = Color.Unspecified,
                    disabledContentColor = Color.Unspecified,
                ),
                onClick = { clickButton() }
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center
                ) {
                    Icon(
                        modifier = Modifier
                            .padding(end = 8.dp)
                            .size(16.dp),
                        painter = painterResource(R.drawable.ico_add),
                        contentDescription = ""
                    )
                    Text(
                        text = textButton,
                        fontSize = 16.sp.nonScaledSp,
                        lineHeight = 24.sp.nonScaledSp,
                        fontWeight = FontWeight(500)
                    )
                }
            }
        }
        if (customButton != null) {
            customButton()
        }
    }
}