package com.example.myexpenses.data

import android.annotation.SuppressLint
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.myexpenses.R
import com.example.myexpenses.nonScaledSp
import java.text.SimpleDateFormat
import java.util.Currency
import java.util.Locale

object Helper {
    val receiptTypes = arrayOf(
        "Self entertainment",
        "Taxi",
        "Hotel",
        "Train",
        "OP purchase",
        "Gifts",
        "Spend time",
        "Friend entertainment",
        "Communication"
    )
    /*val filterTime = arrayOf("Today", "Yesterday", "Week", "Two weeks", "Month")*/

    val formatDouble = { amount:String -> "%.2f".format(amount.replace(",",".").toDouble()) }

    val paymentMethod = arrayOf("Card", "Cash")
    val travelTypes = arrayOf("Round Trip", "Multiple destinations")
    val menuItems = listOf(
        MenuItem(R.drawable.ico_expenses, Route.EXPENSES),
        MenuItem(R.drawable.ico_travel, Route.TRAVEL),
        MenuItem(R.drawable.ico_add_receipt, Route.ADD_RECEIPT),
        MenuItem(R.drawable.ico_exchanges, Route.EXCHANGES),
        MenuItem(R.drawable.ico_more, Route.MORE)
    )

    val bRadius = RoundedCornerShape(8.dp)

    object Color {
        val White = Color(0xFFF3F3F3)
        val White10 = Color(0x19F3F3F3)
        val White50 = Color(0x80F3F3F3)
        val White70 = Color(0xB3F3F3F3)

        val Black = Color(0xFF1C1C1C)
        val Black2C = Color(0xFF2C2C2C)
        val Black3C = Color(0xFF3C3C3C)
        val Black0E = Color(0xFF0E0E0E)

        val Blue = Color(0xFF3077FF)
        val Red = Color(0xFFEB3737)

    }

    val modifierAlert = Modifier.clip(bRadius).background(Color.Black2C)
        .border(width = 1.5.dp, color = Color.White10, shape = bRadius)
        .padding(25.dp)


    fun getAvailableCurrencies(): Array<String> {
        val availableCurrencies = mutableListOf<String>()
        val top = listOf("EUR", "USD", "UAH", "CZK", "HUF", "DKK", "CHF")
        val locales = Locale.getAvailableLocales()
        for (locale in locales) {
            try {
                val currency = Currency.getInstance(locale)
                if (availableCurrencies.none { it == currency.currencyCode }) {
                    if (currency.currencyCode !in top) {
                        availableCurrencies.add(currency.currencyCode)
                    }
                }
            } catch (e: Exception) {
                continue
            }
        }

        return (top + availableCurrencies.toTypedArray().sortedArray()).toTypedArray()
    }
    @SuppressLint("SimpleDateFormat")
    fun fData(ts:Long):String {return SimpleDateFormat("MM/dd/yyyy").format(ts)}
    fun getCurrencySymbol(currency: String): String {
        return if (currency.isNotEmpty()) Currency.getInstance(currency).symbol + " " else ""
    }

    @Composable
    fun Text(text: String, modifier: Modifier = Modifier, textAlign: TextAlign = TextAlign.Left) {
        Text(
            modifier = modifier,
            text = text,
            color = Color.White,
            fontSize = 16.sp.nonScaledSp,
            lineHeight = 24.sp.nonScaledSp,
            fontWeight = FontWeight(500),
            textAlign = textAlign
        )
    }

    @Composable
    fun TextH6(text: String, modifier: Modifier = Modifier, textAlign: TextAlign = TextAlign.Left) {
        Text(
            modifier = modifier,
            text = text,
            color = Color.White70,
            fontSize = 12.sp.nonScaledSp,
            lineHeight = 16.sp.nonScaledSp,
            fontWeight = FontWeight(500),
            textAlign = textAlign
        )
    }

    @Composable
    fun TextH2(text: String, textAlign: TextAlign = TextAlign.Left) {
        Text(
            text = text,
            color = Color.White,
            fontSize = 20.sp.nonScaledSp,
            lineHeight = 24.sp.nonScaledSp,
            fontWeight = FontWeight(700),
            textAlign = textAlign
        )
    }

    @Composable
    fun TextH1(text: String, textAlign: TextAlign = TextAlign.Left) {
        Text(
            text = text,
            color = Color.White,
            fontSize = 24.sp.nonScaledSp,
            lineHeight = 32.sp.nonScaledSp,
            fontWeight = FontWeight(700),
            textAlign = textAlign
        )
    }

    @Composable
    fun HDivider() {
        HorizontalDivider(
            modifier = Modifier.padding(0.dp, 16.dp),
            color = Color.White10,
            thickness = 1.dp
        )
    }

    @Composable
    fun ButtonBlue(
        onClick: () -> Unit,
        text: @Composable () -> Unit,
        enabled: Boolean = true,
        modifier: Modifier = Modifier.fillMaxWidth()
    ) {
        Button(
            modifier = modifier,
            shape = RoundedCornerShape(8.dp),
            enabled = enabled,
            colors = ButtonDefaults.buttonColors(
                containerColor = Color.Blue,
                contentColor = Color.White,
                disabledContainerColor = Color(0x0F3077FF),
                disabledContentColor = Color(0x2FF3F3F3),
            ),
            onClick = { onClick() },
        ) {
            text()
        }
    }

    @Composable
    fun ButtonGrey(
        onClick: () -> Unit,
        text: @Composable () -> Unit,
        enabled: Boolean = true,
        modifier: Modifier = Modifier.fillMaxWidth()
    ) {
        Button(
            modifier = modifier,
            shape = RoundedCornerShape(8.dp),
            enabled = enabled,
            colors = ButtonDefaults.buttonColors(
                containerColor = Color.Black3C,
                contentColor = Color.White,
                disabledContainerColor = Color(0x0F3077FF),
                disabledContentColor = Color(0x2FF3F3F3),
            ),
            onClick = { onClick() },
        ) {
            text()
        }
    }
    @Composable
    fun ButtonGrey3C(
        onClick: () -> Unit,
        text: @Composable () -> Unit,
        enabled: Boolean = true
    ) {
        Button(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(8.dp),
            enabled = enabled,
            colors = ButtonDefaults.buttonColors(
                containerColor = Color.Black3C,
                contentColor = Color.White,
                disabledContainerColor = Color(0x0F3077FF),
                disabledContentColor = Color(0x2FF3F3F3),
            ),
            onClick = { onClick() },
        ) {
            text()
        }
    }

    @Composable
    fun TopBar(
        title: String,
        row: (()-> Unit)? = null,
        rIcon: @Composable (() -> Unit)? = null
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().background(Color.Black).padding(16.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Start
            ) {
                if (row != null) IconButton( modifier = Modifier.padding(end = 12.dp), onClick = { row() } ) {
                    Icon(
                        tint = Color.White,
                        modifier = Modifier.size(16.dp),
                        painter = painterResource(R.drawable.ico_row_left),
                        contentDescription = ""
                    )
                }
                TextH1(title)
            }
            if (rIcon!=null){
                rIcon()
            }
        }
    }

    @Composable
    fun BottomBar(
        currentDestination: String,
        onClick: (String) -> Unit
    ) {
        Row(
            modifier = Modifier.background(Color.Black0E).padding(top = 12.dp, bottom = 12.dp)
        ) {
            menuItems.forEach { item ->
                IconButton(
                    modifier = Modifier.weight(1f),
                    onClick = { onClick(item.route) }
                ) {
                    Icon(
                        tint = if (currentDestination == item.route
                            || currentDestination == Route.ADD_EXCHANGES && item.route == Route.EXCHANGES
                            ) Color.Blue else Color.White,
                        modifier = Modifier.size(48.dp),
                        painter = painterResource(item.painter),
                        contentDescription = item.route
                    )
                }
            }
        }
    }
}
