package com.example.myexpenses.data
object Route {
    const val EXPENSES = "Expenses"
    const val TRAVEL = "Travel"
    const val ADD_TRAVEL = "Travel "
    const val ADD_RECEIPT = "Add Receipt"
    const val EXCHANGES = "Exchanges"
    const val ADD_EXCHANGES = "Exchanges "
    const val MORE = "More"
    const val FIRST = "Initialization"
}



