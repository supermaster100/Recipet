package com.example.myexpenses.data.db

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "Budgets")
data class Budget(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val budgetNumber: String,
    val budgetNumberName: String,
    val status: Boolean = true
)