package com.example.myexpenses.ui.screens.more

import androidx.compose.foundation.layout.Column
import androidx.compose.material3.BasicAlertDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.sp
import com.example.myexpenses.data.Helper
import com.example.myexpenses.data.db.Budget
import com.example.myexpenses.nonScaledSp

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ConfimBudgetDeletePopUp(
    budget: Budget,
    cancel: () -> Unit,
    confim: () -> Unit
) {
    BasicAlertDialog(
        modifier = Helper.modifierAlert,
        onDismissRequest = { cancel() },
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Helper.TextH2(text = "Delete the budget number", textAlign = TextAlign.Center)
            Helper.HDivider()
            Helper.Text(
                text = "Are you sure you want to delete " +
                        "${budget.budgetNumber}/${budget.budgetNumberName}? You will be able " +
                        "to add this budget number again.",
                textAlign = TextAlign.Center
            )
            Helper.HDivider()
            Helper.ButtonBlue(onClick = { cancel() }, text = { Helper.Text("Do not delete") })
            Helper.ButtonGrey(
                onClick = { confim() },
                text = {
                    Text(
                        text = "Delete",
                        color = Helper.Color.Red,
                        fontSize = 16.sp.nonScaledSp,
                        lineHeight = 24.sp.nonScaledSp
                    )
                }
            )
        }

    }
}