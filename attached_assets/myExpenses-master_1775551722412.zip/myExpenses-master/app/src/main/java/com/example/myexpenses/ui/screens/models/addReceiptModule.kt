package com.example.myexpenses.ui.screens.models

import androidx.lifecycle.ViewModel
import com.example.myexpenses.data.db.Budget
import com.example.myexpenses.data.db.ExpenseDao
import com.example.myexpenses.data.db.Receipt

class AddReceiptModule(private val expenseDao: ExpenseDao) : ViewModel() {

    suspend fun get(id: Long): Receipt {
        return expenseDao.getReceipt(id)
    }
    suspend fun getLast(): String {
        val listEx = expenseDao.getLastReceipt()
        return if (listEx.isEmpty()) "" else listEx[0]
    }
    suspend fun getAll(): List<Receipt> {
        return expenseDao.getReceipts()
    }
    suspend fun insert(receipt: Receipt) {
        expenseDao.insertReceipt(receipt)
    }
    suspend fun update(receipt: Receipt) {
        expenseDao.updateReceipt(receipt)
    }
    suspend fun getBudgets(): List<Budget> {
        return expenseDao.getBudgets()
    }
}

