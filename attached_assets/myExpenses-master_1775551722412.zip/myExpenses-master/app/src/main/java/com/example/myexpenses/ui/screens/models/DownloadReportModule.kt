package com.example.myexpenses.ui.screens.models

import androidx.lifecycle.ViewModel
import com.example.myexpenses.data.db.Exchange
import com.example.myexpenses.data.db.ExpenseDao
import com.example.myexpenses.data.db.General
import com.example.myexpenses.data.db.Leg
import com.example.myexpenses.data.db.Receipt
import com.example.myexpenses.data.db.Travel

class DownloadReportModule(private val expenseDao: ExpenseDao) : ViewModel() {

    suspend fun getGeneral(): List<General> {
        return expenseDao.getGeneral()
    }

    suspend fun getLeg():List<Leg> {
        return expenseDao.getLegs()
    }
    suspend fun updateTravels(id:Long, tms:Long) {
        expenseDao.updateTravels(id, tms)
        expenseDao.deleteLegs()
    }
    suspend fun getTravels(lId: Long): List<Travel> {
        return expenseDao.getTravels(lId)
    }

    suspend fun getExchanges(): List<Exchange> {
        return expenseDao.getExchanges()
    }

    suspend fun deleteExchanges(tms:Long) {
        expenseDao.deleteExchanges(tms)
    }

    suspend fun getReceipts(): List<Receipt> {
        return expenseDao.getReceipts()
    }
    suspend fun deleteReceipts(tms:Long) {
        expenseDao.deleteReceipts(tms)
    }
}