package com.example.myexpenses.ui.screens

import android.annotation.SuppressLint
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavController
import com.example.myexpenses.R
import com.example.myexpenses.data.Helper
import com.example.myexpenses.data.Route
import com.example.myexpenses.data.db.General
import com.example.myexpenses.data.db.Leg
import com.example.myexpenses.data.db.Travel
import com.example.myexpenses.ui.AppViewModelProvider
import com.example.myexpenses.ui.components.Await
import com.example.myexpenses.ui.components.DoExport
import com.example.myexpenses.ui.components.EmptyList
import com.example.myexpenses.ui.components.UnsavedChanges
import com.example.myexpenses.ui.screens.models.AddTravelModule
import com.example.myexpenses.ui.screens.travel.AddTravel
import com.example.myexpenses.ui.screens.travel.MultipleDestinations
import com.example.myexpenses.ui.screens.travel.StopTravelPopUp
import com.example.myexpenses.ui.screens.travel.TravelInfo
import kotlinx.coroutines.launch

@SuppressLint("MutableCollectionMutableState", "CoroutineCreationDuringComposition")
@Composable
fun Travel(
    navController: NavController,
    add: Boolean = false,
    travelModel: AddTravelModule = viewModel(factory = AppViewModelProvider.Factory),
) {

    val currentDestination = navController.currentDestination?.route ?: ""
    val coroutineScope = rememberCoroutineScope()
    var legs: List<Leg>? by remember { mutableStateOf(null) }
    var travels: List<Travel>? by remember { mutableStateOf(null) }
    var general: List<General>? by remember { mutableStateOf(null) }
    var addTravelMod by remember { mutableStateOf(add) }
    var iTtavel by remember { mutableIntStateOf(-1) }

    var alreadyChange by remember { mutableStateOf(false) }
    var unsavedChanges by remember { mutableStateOf(false) }
    var unsavedChangesAct by remember { mutableStateOf("") }
    if (unsavedChanges) UnsavedChanges(
        back = {
            if (unsavedChangesAct == "Back") {
                navController.navigate(Route.TRAVEL)
            } else {
                navController.navigate(unsavedChangesAct)
            }
            unsavedChanges = false
            unsavedChangesAct = ""
        },
        dismiss = { unsavedChanges = false; unsavedChangesAct = "" }
    )

    var doExport by remember { mutableStateOf(false) }
    var stopTravelPopUp by remember { mutableStateOf(false) }
    var travelEndedSuccessfully by remember { mutableStateOf(false) }
    if (stopTravelPopUp) StopTravelPopUp(
        end = {
            stopTravelPopUp = false
            doExport = true
        },
        cancel = { stopTravelPopUp = false }
    )
    val stopTravel = { stopTravelPopUp = true }
    val addDestination ={ addTravelMod = true }

    val editTravel = { newTravel: Travel ->
        val d = coroutineScope.launch {
            travelModel.update(newTravel)
            travels = travelModel.get(legs!![0].id)
        }
    }

    if (legs == null){
        coroutineScope.launch{
            legs = travelModel.getLeg()
        }
        Await()
        return
    }
    if (legs!!.isNotEmpty()) {
        if (travels == null) {
            coroutineScope.launch {
                travels = travelModel.get(legs!![0].id)
            }
            Await()
            return
        }

        if (general == null) {
            coroutineScope.launch {
                general = travelModel.getGeneral()
            }
            Await()
            return
        }
    }

    if (doExport) {
        DoExport(
            endExport = {
                if (it != "Error") {
                    coroutineScope.launch {
                        legs = travelModel.getLeg()
                        travelEndedSuccessfully = true
                    }
                }
                doExport = false
            }
        )
    } else {
        Scaffold(
            topBar = {
                if (addTravelMod) {
                    Helper.TopBar(
                        if (!legs.isNullOrEmpty()) "Add Destination ${travels!!.last().num + 2}" else "Add Travel",
                        {
                            if (alreadyChange){
                                unsavedChanges = true
                                unsavedChangesAct = "Back"
                            } else {
                                addTravelMod = false
                            }
                        }
                    )
                } else {
                    if (iTtavel != -1) {
                        Helper.TopBar(
                            "Destination ${iTtavel + 1}",
                            { iTtavel = -1 }
                        )
                    } else {
                        Helper.TopBar(currentDestination)
                    }
                }
            },
            bottomBar = {
                Helper.BottomBar(currentDestination) {
                    if (addTravelMod && alreadyChange) {
                        unsavedChanges = true
                        unsavedChangesAct = it
                    } else
                        navController.navigate(it)
                }
            },
            containerColor = Helper.Color.Black,
            contentColor = Helper.Color.White
        ) {
            Column(
                modifier = Modifier
                    .padding(it)
                    .fillMaxSize()
            ) {
                if (addTravelMod) {
                    if (legs!!.isNotEmpty()) {
                        AddTravel(
                            navController,
                            travel = travels!!.last(),
                            alreadyChange = { alreadyChange = true }
                        )
                    } else {
                        AddTravel(
                            navController,
                            alreadyChange = { alreadyChange = true }
                        )
                    }
                } else if (legs!!.isNotEmpty()) {
                    if (legs!![0].type == "Round Trip") {
                        TravelInfo(
                            leg = legs!![0],
                            travel = travels!![0],
                            general = general!![0],
                            stopTravel = stopTravel,
                            editTravel = editTravel
                        )
                    } else {
                        if (iTtavel == -1)
                            MultipleDestinations(
                                leg = legs!![0],
                                travels = travels!!,
                                stopTravel = stopTravel,
                                addDestination = addDestination,
                                details = { iTtavel = it }
                            )
                        else
                            TravelInfo(
                                leg = legs!![0],
                                travel = travels!![iTtavel],
                                general = general!![0],
                                editTravel = editTravel
                            )
                    }
                } else {
                    EmptyList(
                        ico = painterResource(
                            if (travelEndedSuccessfully)
                                R.drawable.ico_travel_su
                            else
                                R.drawable.ico_travel_screen
                        ),
                        text1 =
                        if (travelEndedSuccessfully)
                            "The travel ended successfully"
                        else
                            "You don’t have travels",
                        text2 =
                        if (travelEndedSuccessfully)
                            "You can now sand it via email and add new travel"
                        else
                            "Please add a travel to track your expenses",
                        textButton = "Add Travel",
                        clickButton = { addTravelMod = true }
                    )
                }
            }
        }
    }
}