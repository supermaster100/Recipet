package com.example.myexpenses.ui.screens.models

import android.net.Uri
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.core.net.toUri
import androidx.lifecycle.ViewModel
import com.example.myexpenses.data.CMediaStore
import com.example.myexpenses.data.Helper
import com.example.myexpenses.data.db.Exchange
import com.example.myexpenses.data.db.General
import com.example.myexpenses.data.db.Receipt
import com.example.myexpenses.data.db.Travel
import org.json.JSONArray
import org.json.JSONException
import java.io.File

class MediaStoreModel(private val cMediaStore: CMediaStore) : ViewModel() {
    private var takePictureFlag = false

    fun takePicture(imageCapture: ImageCapture, callBack: (Uri) -> Unit) {
        if (takePictureFlag) return
        takePictureFlag = true

        cMediaStore.takePicture(imageCapture,
            object : ImageCapture.OnImageSavedCallback {
                override fun onError(error: ImageCaptureException) {
                    takePictureFlag = false
                }

                override fun onImageSaved(outputFileResults: ImageCapture.OutputFileResults) {
                    outputFileResults.savedUri?.let {
                        takePictureFlag = false
                        callBack(it)
                    }
                }
            }
        )
    }

    fun saveToLocal(new: String, old: String): String {
        if (new != old) {
            cMediaStore.deleteFromLocal(old)
            return saveToLocal(new)
        }
        return old
    }

    fun saveToLocal(uri: String): String {
        return cMediaStore.saveToLocal(uri)
    }

    fun getAllFromLocal(): List<Uri> {
        return cMediaStore.getAllFromLocal()
    }
    fun getImageDate(file:String):String{
        if (file.isEmpty() || !File(file).exists()) return "---"
        val ts = cMediaStore.getImageCreationDate(File(file).toUri()) ?: return "---"
        return Helper.fData(ts)
    }
    fun deletePhoto(uri: Uri) {
        cMediaStore.deletePhoto(uri)
    }

    fun deletePhotos() {
        cMediaStore.deletePhotos()
    }

    fun deleteSelectedPhoto(selected: List<Int>, db: List<Any>) {
        /*for (item in db) {
            var idEv: Int = -1
            var uriEvImg = ""
            when (item) {
                is Hotel -> {
                    idEv = item.id
                    uriEvImg = item.pictureUri
                }

                is Expense -> {
                    idEv = item.id
                    uriEvImg = item.pictureUri
                }

                is Exchange -> {
                    idEv = item.id
                    *//*uriEvImg = item.pictureUri*//*
                }

                is Leg -> {
                    idEv = item.id
                    uriEvImg = ""
                }
            }
            if (idEv in selected) {
                cMediaStore.deleteFromLocal(uriEvImg)
            }
        }*/
    }

    fun doExport(
        uri: Uri?,
        general: General,
        travelList: List<Travel>?,
        expensesList: List<Receipt>,
        exchangesList: List<Exchange>,
    ): String {
        return cMediaStore.doExport(uri, general, travelList, expensesList,  exchangesList, getCountryFromJson(true))
    }

    fun getCountryFromJson(export:Boolean = false): List<List<String>>{
        val data = mutableListOf<MutableList<String>>()

        try {
            val json = JSONArray(cMediaStore.getCountryFromJson())
            for (i in 0 until json.length()) {
                val item = json.getJSONObject(i)
                if (data.isEmpty()) {
                    data.add(mutableListOf( item.getString("Trip")))
                } else {
                    data[0].add(item.getString("Trip"))
                }
                if (export){
                    data.add(mutableListOf(item.getString("COUNTRY"), item.getString("REGION")))
                }
            }
        } catch (e: JSONException) {
            e.printStackTrace()
        }
        return data.toList()
    }
}
