package com.example.myexpenses.ui.screens.travel

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.myexpenses.R
import com.example.myexpenses.data.Helper
import com.example.myexpenses.data.db.General
import com.example.myexpenses.data.db.Leg
import com.example.myexpenses.data.db.Travel
import com.example.myexpenses.nonScaledSp
import com.example.myexpenses.ui.AppViewModelProvider
import com.example.myexpenses.ui.components.ImageField
import com.example.myexpenses.ui.components.OwnTextField
import com.example.myexpenses.ui.components.OwnTextMultiLineField
import com.example.myexpenses.ui.components.PhotoPopUp
import com.example.myexpenses.ui.screens.models.MediaStoreModel

@Composable
fun TravelInfo(
    leg: Leg,
    travel: Travel,
    general: General,
    stopTravel: ()->Unit = {},
    editTravel: (Travel)->Unit,
    viewMedia: MediaStoreModel = viewModel(factory = AppViewModelProvider.Factory)
) {
    var more: Boolean by remember { mutableStateOf(false) }

    val focusRequester = remember { FocusRequester() }
    var edit: Int by remember { mutableIntStateOf(0) }
    var editValue: String by remember { mutableStateOf("") }
    val resetEdit = {
        edit = 0
        editValue = ""
    }


    var popUpImage by remember { mutableStateOf(false) }
    if (popUpImage) PhotoPopUp(
        cancel = { popUpImage = false },
        changeImage = {
            editTravel(travel.copy(
                photo = if (travel.photo.isEmpty()) {
                    viewMedia.saveToLocal(it.toString())
                } else {
                    viewMedia.saveToLocal(it.toString(), travel.photo)
                }
            ))
            popUpImage = false
        }
    )

    Column(
        modifier = Modifier
            .padding(16.dp)
            .verticalScroll(rememberScrollState())
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .clip(Helper.bRadius)
                .background(Helper.Color.Blue)
                .border(width = 1.5.dp, color = Helper.Color.White10, shape = Helper.bRadius)
                .padding(12.dp)

        ) {
            if (leg.type == "Round Trip") {
                Helper.TextH6(text = "Type")
                Helper.Text(leg.type)
                Spacer(Modifier.size(8.dp))
            }

            Helper.TextH6(text = "Journey")
            Helper.Text("${travel.departure} - ${travel.destination}")
            Spacer(Modifier.size(8.dp))
            Helper.TextH6(text = "Duration")
            Helper.Text("${Helper.fData(travel.departureDate)} - ${Helper.fData(travel.returnDate)}")
        }
        Spacer(Modifier.size(16.dp))
        if (leg.type == "Round Trip") {
            Button(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(8.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = Helper.Color.White,
                    contentColor = Helper.Color.Black0E,
                    disabledContainerColor = Color.Unspecified,
                    disabledContentColor = Color.Unspecified,
                ),
                onClick = { stopTravel() },
            ) {
                Column (
                    modifier = Modifier.fillMaxWidth(),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Icon(
                        painter = painterResource(R.drawable.ico_flag),
                        contentDescription = "",
                        modifier = Modifier.size(24.dp)
                    )
                    Spacer(Modifier.size(8.dp))
                    Text(text = "End Trip", fontSize = 14.sp.nonScaledSp)
                }
            }
            Spacer(Modifier.size(8.dp))
        }
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .clip(Helper.bRadius)
                .background(Helper.Color.Black2C)
                .padding(16.dp)
        ) {
            Helper.TextH2(text = "General Info")
            Spacer(Modifier.size(16.dp))

            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(Helper.bRadius)
                    .background(Helper.Color.Black3C)
                    .padding(16.dp)
            ) {
                Helper.TextH6("Budget number")
                Helper.Text(travel.budget)

                if (more) {
                    Helper.HDivider()
                    Helper.TextH6("Worker number")
                    Helper.Text(general.workerNumber)
                    Helper.HDivider()
                    Helper.TextH6("Department")
                    Helper.Text(general.department)
                    Helper.HDivider()
                    Helper.TextH6("Month / Year")
                    Helper.Text(general.monthYear)

                    Helper.TextH6(
                        text = "Hide",
                        modifier = Modifier
                            .drawBehind {
                                val strokeWidthPx = 1.dp.toPx()
                                val verticalOffset = size.height - 2.sp.toPx()
                                drawLine(
                                    color = Color(0xFFF3F3F3),
                                    strokeWidth = strokeWidthPx,
                                    start = Offset(0f, verticalOffset),
                                    end = Offset(size.width, verticalOffset)
                                )
                            }
                            .clickable { more = false }
                    )
                } else {
                    Helper.TextH6(
                        text = "More",
                        modifier = Modifier
                            .drawBehind {
                                val strokeWidthPx = 1.dp.toPx()
                                val verticalOffset = size.height - 2.sp.toPx()
                                drawLine(
                                    color = Color(0xFFF3F3F3),
                                    strokeWidth = strokeWidthPx,
                                    start = Offset(0f, verticalOffset),
                                    end = Offset(size.width, verticalOffset)
                                )
                            }
                            .clickable { more = true }
                    )
                }
            }

            Spacer(Modifier.size(16.dp))
            Helper.TextH2(text = "Place to stay Info")
            Spacer(Modifier.size(16.dp))
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(Helper.bRadius)
                    .background(Helper.Color.Black3C)
                    .padding(16.dp)
            ) {
                Helper.TextH6("Hotel Name")
                Helper.Text(travel.placeOfStaying)
                Helper.HDivider()
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Column(horizontalAlignment = Alignment.Start) {
                        Helper.TextH6("Number of Nights")
                        if (edit != 1) Helper.Text(travel.nights)
                    }
                    if (edit != 1) {
                        Text(text = "")
                        Column(horizontalAlignment = Alignment.End) {
                            Icon(
                                modifier = Modifier.clickable {
                                    edit = 1
                                    editValue = travel.nights
                                },
                                painter = painterResource(R.drawable.ico_pencil),
                                contentDescription = ""
                            )
                        }
                    }
                }
                if (edit == 1) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        OwnTextField(
                            value = editValue,
                            changeValue = { editValue = it },
                            label = null,
                            type = "Int",
                            w = 0.70f,
                            modifier = Modifier.focusRequester(focusRequester)
                        )
                        Spacer(Modifier.fillMaxWidth(0.1f))
                        Helper.TextH6(
                            text = "Save",
                            modifier = Modifier.clickable {
                                editTravel(travel.copy(nights = editValue))
                                resetEdit()
                            }
                        )
                        LaunchedEffect(Unit) {
                            focusRequester.requestFocus()
                        }
                    }
                }

                if (!travel.arbitraryLocation) {
                    Helper.HDivider()
                    Helper.TextH6("Payment method")
                    Helper.Text(travel.paymentMethod)
                    Helper.HDivider()
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Column(horizontalAlignment = Alignment.Start) {
                            Helper.TextH6("Price per night")
                            Helper.Text("${Helper.getCurrencySymbol(travel.currencyPN)}${travel.ratePerNight}")
                        }
                        Text(text = "")
                        Column(horizontalAlignment = Alignment.End) {
                            Helper.TextH6("Currency")
                            Helper.Text(travel.currencyPN)
                        }
                    }
                    Helper.HDivider()
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Column(horizontalAlignment = Alignment.Start) {
                            Helper.TextH6("Total price")
                            Helper.Text(
                                "${Helper.getCurrencySymbol(travel.currencyPN)}${
                                    "%.2f".format(travel.ratePerNight.toDouble() * travel.nights.toDouble())
                                }"
                            )
                        }
                        Text(text = "")
                        Column(horizontalAlignment = Alignment.End) {
                            Helper.TextH6("Currency")
                            Helper.Text(travel.currencyPN)
                        }
                    }
                    Helper.HDivider()
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Column(horizontalAlignment = Alignment.Start) {
                            Helper.TextH6("Hotel extra fees")
                            Helper.Text("${Helper.getCurrencySymbol(travel.currencyHEF)}${travel.hotelExtraFees}")
                        }
                        Text(text = "")
                        Column(horizontalAlignment = Alignment.End) {
                            Helper.TextH6("Currency")
                            Helper.Text(travel.currencyHEF)
                        }
                    }
                    Helper.HDivider()
                    Helper.TextH6("Breakfast")
                    Helper.Text(if (travel.breakfast) "Include" else "No include")
                    Helper.HDivider()
                    ImageField(
                        currentUri = travel.photo,
                        popUpImage = { popUpImage = true },
                        title = null
                    )
                }
            }
            Spacer(Modifier.size(16.dp))
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(Helper.bRadius)
                    .background(Helper.Color.Black3C)
                    .padding(16.dp)
            ) {
                Helper.TextH6("Description")

                if (edit == 2) {
                    OwnTextMultiLineField(
                        modifier = Modifier.focusRequester(focusRequester),
                        value = editValue,
                        changeValue = { editValue = it },
                        label = null,
                        placeholder = "Enter you description here"
                    )
                    Helper.TextH6(
                        text = "Save",
                        modifier = Modifier
                            .drawBehind {
                                val strokeWidthPx = 1.dp.toPx()
                                val verticalOffset = size.height - 2.sp.toPx()
                                drawLine(
                                    color = Color(0xFFF3F3F3),
                                    strokeWidth = strokeWidthPx,
                                    start = Offset(0f, verticalOffset),
                                    end = Offset(size.width, verticalOffset)
                                )
                            }.clickable {
                                editTravel(travel.copy(description = editValue))
                                resetEdit()
                            }
                    )
                    LaunchedEffect(Unit) {
                        focusRequester.requestFocus()
                    }
                } else {
                    Helper.Text(travel.description)
                    Helper.TextH6(
                        text = "Edit",
                        modifier = Modifier
                            .drawBehind {
                                val strokeWidthPx = 1.dp.toPx()
                                val verticalOffset = size.height - 2.sp.toPx()
                                drawLine(
                                    color = Color(0xFFF3F3F3),
                                    strokeWidth = strokeWidthPx,
                                    start = Offset(0f, verticalOffset),
                                    end = Offset(size.width, verticalOffset)
                                )
                            }.clickable {
                                edit = 2
                                editValue = travel.description
                            }
                    )
                }
            }
        }
    }
}