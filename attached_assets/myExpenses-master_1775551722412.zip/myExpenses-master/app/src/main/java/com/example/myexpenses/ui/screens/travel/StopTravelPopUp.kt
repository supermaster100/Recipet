package com.example.myexpenses.ui.screens.travel;

import androidx.compose.foundation.layout.Column
import androidx.compose.material3.BasicAlertDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.text.style.TextAlign
import com.example.myexpenses.data.Helper

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StopTravelPopUp(
    end: () -> Unit,
    cancel: () -> Unit
) {
    BasicAlertDialog(
        modifier = Helper.modifierAlert,
        onDismissRequest = { cancel() },
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            content = {
                Helper.TextH2("Do you want to end this travel?", textAlign = TextAlign.Center)
                Helper.HDivider()
                Helper.Text("After closing this form YOU CAN`T EDIT it again", textAlign = TextAlign.Center)
                Helper.HDivider()
                Helper.ButtonBlue(onClick = { end() }, text = { Helper.Text("End trip") })
                Helper.ButtonGrey(onClick = { cancel() }, text = { Helper.Text("Don’t end") })
            }
        )
    }
}
