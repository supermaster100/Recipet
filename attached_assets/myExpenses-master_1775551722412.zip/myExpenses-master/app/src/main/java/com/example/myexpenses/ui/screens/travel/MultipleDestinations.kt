package com.example.myexpenses.ui.screens.travel

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.myexpenses.R
import com.example.myexpenses.data.Helper
import com.example.myexpenses.data.db.Leg
import com.example.myexpenses.data.db.Travel
import com.example.myexpenses.nonScaledSp

@Composable
fun MultipleDestinations(
    leg: Leg,
    travels: List<Travel>,
    stopTravel: () -> Unit,
    addDestination: () -> Unit,
    details: (Int) -> Unit
) {
    Column(
        modifier = Modifier
            .padding(16.dp)
            .verticalScroll(rememberScrollState())
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .clip(Helper.bRadius)
                .background(Helper.Color.Black3C)
                .border(width = 1.5.dp, color = Helper.Color.White10, shape = Helper.bRadius)
                .padding(12.dp)

        ) {
            Helper.TextH6(text = "Type")
            Helper.Text(leg.type)
            Helper.TextH6(text = "Budget number")
            Helper.Text(travels[0].budget)
        }
        Spacer(Modifier.size(16.dp))
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ){
            Button(
                modifier = Modifier.fillMaxWidth(0.48f),
                shape = RoundedCornerShape(8.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = Helper.Color.White,
                    contentColor = Helper.Color.Black0E,
                    disabledContainerColor = Color.Unspecified,
                    disabledContentColor = Color.Unspecified,
                ),
                onClick = { addDestination() },
            ) {
                Column (
                    modifier = Modifier.fillMaxWidth(),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ){
                    Icon(
                        painter = painterResource(R.drawable.ico_add),
                        contentDescription = "",
                        modifier = Modifier.size(24.dp)
                    )
                    Spacer(Modifier.size(8.dp))
                    Text(text = "Add Destination", fontSize = 14.sp.nonScaledSp)
                }
            }
            Text(text = "")
            Button(
                modifier = Modifier.fillMaxWidth(0.92f),
                shape = RoundedCornerShape(8.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = Helper.Color.White,
                    contentColor = Helper.Color.Black0E,
                    disabledContainerColor = Color.Unspecified,
                    disabledContentColor = Color.Unspecified,
                ),
                onClick = { stopTravel() },
            ) {
                Column (
                    modifier = Modifier.fillMaxWidth(),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Icon(
                        painter = painterResource(R.drawable.ico_flag),
                        contentDescription = "",
                        modifier = Modifier.size(24.dp)
                    )
                    Spacer(Modifier.size(8.dp))
                    Text(text = "End Trip", fontSize = 14.sp.nonScaledSp)
                }
            }
        }
        travels.forEachIndexed{ index, travel ->
            Spacer(Modifier.size(16.dp))
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(Helper.bRadius)
                    .background(Helper.Color.Black3C)
                    .padding(12.dp)
                    .clickable {
                        details(index)
                    },
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column (
                    horizontalAlignment = Alignment.Start
                ){
                    Helper.TextH6(text = "Destination ${index+1}")
                    Spacer(Modifier.size(4.dp))
                    Helper.Text("${travel.departure} - ${travel.destination}")
                    Spacer(Modifier.size(4.dp))
                    Helper.Text("${Helper.fData(travel.departureDate)} - ${Helper.fData(travel.returnDate)}")
                }
                Text(text = "")
                Icon(
                    modifier = Modifier.size(16.dp),
                    painter = painterResource(R.drawable.ico_row_right),
                    tint = Helper.Color.White,
                    contentDescription = ""
                )
            }
        }
    }
}