package com.example.myexpenses.ui.screens.exchanges

import android.annotation.SuppressLint
import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Icon
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.core.net.toUri
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavController
import com.example.myexpenses.R
import com.example.myexpenses.data.Helper
import com.example.myexpenses.data.Route
import com.example.myexpenses.data.db.Exchange
import com.example.myexpenses.ui.AppViewModelProvider
import com.example.myexpenses.ui.components.DateField
import com.example.myexpenses.ui.components.ImageField
import com.example.myexpenses.ui.components.OwnTextField
import com.example.myexpenses.ui.components.OwnTextMultiLineField
import com.example.myexpenses.ui.components.PhotoPopUp
import com.example.myexpenses.ui.components.ReceiptIsEmpty
import com.example.myexpenses.ui.components.SelectedField
import com.example.myexpenses.ui.screens.models.AddExchangeModule
import com.example.myexpenses.ui.screens.models.MediaStoreModel
import kotlinx.coroutines.launch
import java.io.File

@SuppressLint("CoroutineCreationDuringComposition")
@Composable
fun AddExchange(
    navController: NavController,
    alreadyChange: () -> Unit = {},
    itemId: Long? = null,
    exchangeModel: AddExchangeModule = viewModel(factory = AppViewModelProvider.Factory),
    viewMedia: MediaStoreModel = viewModel(factory = AppViewModelProvider.Factory)
) {
    val coroutineScope = rememberCoroutineScope()
    var editItem: Exchange? by remember { mutableStateOf(null) }

    if (itemId != null && editItem == null) {
        coroutineScope.launch {
            editItem = exchangeModel.get(itemId)
        }
        return
    }

    val values = object {
        var dateOfExchange: Long? by remember { mutableStateOf(if (editItem != null) editItem?.dateOfExchange else null) }
        var amountSpent: String by remember { mutableStateOf(if (editItem != null) editItem?.amountSpent ?: "" else "") }
        var spentCurrency: String by remember { mutableStateOf(if (editItem != null) editItem?.spentCurrency ?: "" else "") }
        var amountReceived: String by remember { mutableStateOf(if (editItem != null) editItem?.amountReceived ?: "" else "") }
        var receivedCurrency: String by remember { mutableStateOf(if (editItem != null) editItem?.receivedCurrency ?: "" else "") }
        var description: String by remember { mutableStateOf(if (editItem != null) editItem?.description ?: "" else "") }
        var photo: Uri by remember { mutableStateOf(if (editItem != null) File(editItem!!.photo).toUri() else Uri.EMPTY) }

        fun saveChange() {
            val id = if (editItem != null) editItem!!.id else 0

            val exchange = Exchange(
                id = id,
                dateOfExchange = this.dateOfExchange ?: 0,
                amountSpent = Helper.formatDouble(this.amountSpent),
                spentCurrency = this.spentCurrency,
                amountReceived = Helper.formatDouble(this.amountReceived),
                receivedCurrency = this.receivedCurrency,
                description = this.description,
                photo = if (editItem != null) viewMedia.saveToLocal(
                    this.photo.toString(),
                    File(editItem!!.photo).toUri().toString()
                ) else viewMedia.saveToLocal(this.photo.toString()),
            )
            coroutineScope.launch {
                if (editItem != null) {
                    exchangeModel.update(exchange)
                } else {
                    exchangeModel.insert(exchange)
                }
                navController.navigate(Route.EXCHANGES)
            }
        }
    }

    val errorM = object {
        var dateOfExchange: Boolean by remember { mutableStateOf(false) }
        var amountSpent: Boolean by remember { mutableStateOf(false) }
        var spentCurrency: Boolean by remember { mutableStateOf(false) }
        var amountReceived: Boolean by remember { mutableStateOf(false) }
        var receivedCurrency: Boolean by remember { mutableStateOf(false) }
        var hasError: Boolean by remember { mutableStateOf(false) }
    }

    val setError = fun(): Boolean {
        errorM.dateOfExchange = values.dateOfExchange == null
        errorM.amountSpent = values.amountSpent.isEmpty()
        errorM.spentCurrency = values.spentCurrency.isEmpty()
        errorM.amountReceived = values.amountReceived.isEmpty()
        errorM.receivedCurrency = values.receivedCurrency.isEmpty()
        return errorM.dateOfExchange || errorM.amountSpent || errorM.spentCurrency || errorM.amountReceived || errorM.receivedCurrency
    }
    if (errorM.hasError) {
        errorM.hasError = setError()
    }

    var popUpImage by remember { mutableStateOf(false) }
    if (popUpImage) PhotoPopUp(
        cancel = { popUpImage = false },
        changeImage = {
            alreadyChange()
            values.photo = it
            popUpImage = false
        }
    )

    var receiptIsEmpty by remember { mutableStateOf(false) }
    if (receiptIsEmpty) ReceiptIsEmpty(
        addPhoto = { popUpImage = true; receiptIsEmpty = false },
        doLater = { receiptIsEmpty = false; values.saveChange() },
        dismiss = { receiptIsEmpty = false }
    )

    /*Form*/
    Column(
        modifier = Modifier
            .padding(16.dp)
            .verticalScroll(rememberScrollState())
    ) {
        ImageField(
            currentUri = values.photo,
            popUpImage = { popUpImage=true }
        )
        Spacer(Modifier.size(16.dp))
        Row(
            modifier = Modifier.fillMaxWidth().background(Helper.Color.Black2C).clip(Helper.bRadius)
                .padding(16.dp, 8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            var rTop by remember { mutableStateOf(true) }

            Column(horizontalAlignment = Alignment.Start) {
                Helper.TextH6(if (rTop) values.receivedCurrency.ifEmpty { "---" } else values.spentCurrency.ifEmpty { "---" })
                Helper.Text(
                    if (values.amountReceived.isNotEmpty() && values.amountSpent.isNotEmpty())
                        "1.00"
                    else
                        "-.--"
                )
            }
            Icon(
                modifier = Modifier
                    .clickable { rTop = !rTop }
                    .size(24.dp),
                painter = painterResource(R.drawable.ico_change),
                tint = if (rTop) Helper.Color.White else Helper.Color.Blue,
                contentDescription = ""
            )
            Column(horizontalAlignment = Alignment.End) {
                Helper.TextH6(if (rTop) values.spentCurrency.ifEmpty { "---" } else values.receivedCurrency.ifEmpty { "---" })
                Helper.Text(
                    if (values.amountReceived.isNotEmpty() && values.amountSpent.isNotEmpty())
                        "%.3f".format(
                            if (rTop)
                                values.amountSpent.replace(',', '.')
                                    .toDouble() / values.amountReceived.replace(',', '.').toDouble()
                            else
                                values.amountReceived.replace(',', '.')
                                    .toDouble() / values.amountSpent.replace(',', '.').toDouble()
                        )
                    else
                        "-.---"
                )
            }
        }
        Spacer(Modifier.size(16.dp))
        Row(
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            OwnTextField(
                value = values.amountSpent,
                changeValue = {
                    alreadyChange()
                    values.amountSpent = it
                              },
                label = "Amount spent",
                prefix = Helper.getCurrencySymbol(values.spentCurrency),
                placeholder = "0.00",
                type = "Double",
                w = 0.67f,
                isError = errorM.amountSpent,
                errorText = "Please enter amount"
            )
            Spacer(Modifier.fillMaxWidth(0.1f))
            SelectedField(
                label = "Currency",
                value = values.spentCurrency,
                itemsList = Helper.getAvailableCurrencies(),
                setValue = {
                    alreadyChange()
                    values.spentCurrency = it
                           },
                isError = errorM.spentCurrency,
            )
        }
        Spacer(Modifier.size(16.dp))
        Row(
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            OwnTextField(
                value = values.amountReceived,
                changeValue = {
                    alreadyChange()
                    values.amountReceived = it
                              },
                label = "Amount received",
                prefix = Helper.getCurrencySymbol(values.receivedCurrency),
                placeholder = "0.00",
                type = "Double",
                w = 0.67f,
                isError = errorM.amountReceived,
                errorText = "Please enter amount"
            )
            Spacer(Modifier.fillMaxWidth(0.1f))
            SelectedField(
                label = "Currency",
                value = values.receivedCurrency,
                itemsList = Helper.getAvailableCurrencies(),
                setValue = {
                    alreadyChange()
                    values.receivedCurrency = it
                           },
                isError = errorM.receivedCurrency,
            )
        }
        Spacer(Modifier.size(16.dp))
        DateField(
            value = values.dateOfExchange,
            setValue = { value ->
                alreadyChange()
                values.dateOfExchange = value
                       },
            label = "Date of exchange",
            isError = errorM.dateOfExchange,
            errorText = "Please select the date of exchange"
        )
        Spacer(Modifier.size(16.dp))
        OwnTextMultiLineField(
            value = values.description,
            changeValue = {
                alreadyChange()
                values.description = it
                          },
            label = "Description (Optional)",
            placeholder = "Enter you description here"
        )
        Helper.HDivider()
        Helper.ButtonBlue(
            onClick = {
                errorM.hasError = setError()
                if (!errorM.hasError) {
                    if (Uri.EMPTY.equals(values.photo)) {
                        receiptIsEmpty = true
                    } else {
                        values.saveChange()
                    }
                }
            },
            text = { Helper.Text("Save a receipt") }
        )
    }
}