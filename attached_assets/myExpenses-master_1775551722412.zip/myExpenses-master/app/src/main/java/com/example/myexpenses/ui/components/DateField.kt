package com.example.myexpenses.ui.components

import android.annotation.SuppressLint
import androidx.compose.foundation.interaction.Interaction
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.PressInteraction
import androidx.compose.material3.DatePicker
import androidx.compose.material3.DatePickerDefaults
import androidx.compose.material3.DatePickerDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberDatePickerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import com.example.myexpenses.R
import com.example.myexpenses.data.Helper
import kotlinx.coroutines.channels.BufferOverflow
import kotlinx.coroutines.flow.MutableSharedFlow
import java.text.SimpleDateFormat

@OptIn(ExperimentalMaterial3Api::class)
@SuppressLint("UnrememberedMutableState", "SimpleDateFormat")
@Composable
fun DateField(
    value: Long? = null,
    setValue: (Long?) -> Unit = {},
    label: String = "Label",
    isError: Boolean = false,
    errorText: String = "Missing Field",
    w: Float = 1f
) {
    var openDialog: Boolean by remember { mutableStateOf(false) }
    val interactionSource = remember {
        object : MutableInteractionSource {
            override val interactions = MutableSharedFlow<Interaction>(
                extraBufferCapacity = 16,
                onBufferOverflow = BufferOverflow.DROP_OLDEST,
            )

            override suspend fun emit(interaction: Interaction) {
                when (interaction) {
                    is PressInteraction.Press -> {
                        openDialog = !openDialog
                    }
                }

                interactions.emit(interaction)
            }

            override fun tryEmit(interaction: Interaction): Boolean {
                return interactions.tryEmit(interaction)
            }
        }
    }

    OwnTextField(
        value = if (value == null) "Enter Here" else SimpleDateFormat(stringResource(R.string.date_format)).format(value),
        readOnly = true,
        label = label,
        interactionSource = interactionSource,
        rightIcon =  painterResource(R.drawable.ico_calendar),
        isError = isError,
        errorText = errorText,
        w = w
    )

    if (openDialog) {
        val datePickerState = rememberDatePickerState(value)
        val confirmEnabled = derivedStateOf { datePickerState.selectedDateMillis != null }
        DatePickerDialog(
            onDismissRequest = {
                openDialog = false
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        openDialog = false
                        setValue(datePickerState.selectedDateMillis)
                    },
                    enabled = confirmEnabled.value
                ) {
                    Text("OK", color = Helper.Color.White)
                }
            },
            dismissButton = {
                TextButton(
                    onClick = {
                        openDialog = false
                    }
                ) {
                    Text("Cancel", color = Helper.Color.White)
                }
            }
        ) {
            DatePicker(
                state = datePickerState,
                title = null,
                headline = null,
                showModeToggle = false,
                colors = DatePickerDefaults.colors(
                    selectedYearContainerColor = Helper.Color.Blue,
                    yearContentColor = Helper.Color.White,
                    selectedDayContainerColor = Helper.Color.Blue,
                    selectedDayContentColor = Helper.Color.White,
                    containerColor = Helper.Color.Black2C,
                    titleContentColor = Helper.Color.White,
                    weekdayContentColor = Helper.Color.White,
                    dividerColor = Helper.Color.Black3C
                )
            )
        }
    }
}
