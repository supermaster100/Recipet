package com.example.myexpenses.data

data class MenuItem(
    val painter: Int,
    val route: String
)
