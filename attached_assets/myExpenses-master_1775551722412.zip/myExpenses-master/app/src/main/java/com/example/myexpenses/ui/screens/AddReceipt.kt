package com.example.myexpenses.ui.screens

import android.annotation.SuppressLint
import android.net.Uri
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.core.net.toUri
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavController
import com.example.myexpenses.R
import com.example.myexpenses.data.Helper
import com.example.myexpenses.data.Route
import com.example.myexpenses.data.db.Budget
import com.example.myexpenses.data.db.Receipt
import com.example.myexpenses.ui.AppViewModelProvider
import com.example.myexpenses.ui.components.Await
import com.example.myexpenses.ui.components.DateField
import com.example.myexpenses.ui.components.EmptyList
import com.example.myexpenses.ui.components.ImageField
import com.example.myexpenses.ui.components.OwnTextField
import com.example.myexpenses.ui.components.OwnTextMultiLineField
import com.example.myexpenses.ui.components.PhotoPopUp
import com.example.myexpenses.ui.components.ReceiptIsEmpty
import com.example.myexpenses.ui.components.SelectedField
import com.example.myexpenses.ui.components.UnsavedChanges
import com.example.myexpenses.ui.screens.models.AddReceiptModule
import com.example.myexpenses.ui.screens.models.MediaStoreModel
import kotlinx.coroutines.launch
import java.io.File

@SuppressLint("CoroutineCreationDuringComposition")
@Composable
fun AddReceipt(
    navController: NavController,
    itemId:Long? = null,
    receiptModel: AddReceiptModule = viewModel(factory = AppViewModelProvider.Factory),
    viewMedia: MediaStoreModel = viewModel(factory = AppViewModelProvider.Factory)
) {
    var successfully by remember { mutableStateOf(false) }

    var alreadyChange by remember { mutableStateOf(false) }
    var unsavedChanges by remember { mutableStateOf(false) }
    var unsavedChangesAct by remember { mutableStateOf("") }
    if (unsavedChanges) UnsavedChanges(
        back = {
            navController.navigate(unsavedChangesAct)
            unsavedChanges = false
        },
        dismiss = { unsavedChanges = false; unsavedChangesAct = "" }
    )

    val coroutineScope = rememberCoroutineScope()
    var budgets: List<Budget>? by remember { mutableStateOf(null) }
    var editItem: Receipt? by remember { mutableStateOf(null) }
    var lastCurrency: String? by remember { mutableStateOf(null) }

    if (budgets == null) {
        coroutineScope.launch {
            budgets = receiptModel.getBudgets()
        }
        Await()
        return
    }
    if (itemId != null && editItem == null) {
        coroutineScope.launch {
            editItem = receiptModel.get(itemId)
        }
        Await()
        return
    }
    if (lastCurrency == null) {
        coroutineScope.launch {
            lastCurrency = receiptModel.getLast()
        }
        Await()
        return
    }

    val values = object {
        var expensesType: String by remember { mutableStateOf(if (editItem != null) editItem!!.expensesType else "") }
        var amount: String by remember { mutableStateOf(if (editItem != null) editItem!!.amount else "") }
        var budget: String by remember { mutableStateOf(if (editItem != null) editItem!!.budget else "") }
        var currency: String by remember { mutableStateOf(if (editItem != null) editItem!!.currency else lastCurrency ?: "") }
        var payingDate: Long? by remember { mutableStateOf(if (editItem != null) editItem!!.payingDate else null) }
        var numberOfPeople: String by remember { mutableStateOf(if (editItem != null) editItem!!.numberOfPeople else "1") }
        var description: String by remember { mutableStateOf(if (editItem != null) editItem!!.description else "") }
        var photo: Uri by remember { mutableStateOf(if (editItem != null) File(editItem!!.photo).toUri() else Uri.EMPTY) }

        fun saveChange() {
            val id = if (editItem != null) editItem!!.id else 0
            val receipt = Receipt(
                id = id,
                expensesType = expensesType,
                amount = Helper.formatDouble(amount),
                currency = currency,
                budget = budget,
                numberOfPeople = numberOfPeople,
                payingDate = payingDate ?: 0,
                description = description,
                photo = if (editItem != null) viewMedia.saveToLocal(
                    this.photo.toString(),
                    File(editItem!!.photo).toUri().toString()
                ) else viewMedia.saveToLocal(this.photo.toString()),
            )

            coroutineScope.launch {
                if (editItem != null) {
                    receiptModel.update(receipt)
                } else {
                    receiptModel.insert(receipt)
                }
                successfully = true
            }
        }
    }

    val errorM = object {
        var expensesType: Boolean by remember { mutableStateOf(false) }
        var amount: Boolean by remember { mutableStateOf(false) }
        var currency: Boolean by remember { mutableStateOf(false) }
        var budget: Boolean by remember { mutableStateOf(false) }
        var numberOfPeople: Boolean by remember { mutableStateOf(false) }
        var payingDate: Boolean by remember { mutableStateOf(false) }
        var hasError: Boolean by remember { mutableStateOf(false) }
    }

    val setError = fun(): Boolean {
        errorM.expensesType = values.expensesType.isEmpty()
        errorM.amount = values.amount.isEmpty()
        errorM.currency = values.currency.isEmpty()
        errorM.budget = values.budget.isEmpty()
        errorM.numberOfPeople = values.numberOfPeople.isEmpty()
        errorM.payingDate = values.payingDate == null
        return errorM.expensesType || errorM.amount || errorM.currency || errorM.budget || errorM.numberOfPeople || errorM.payingDate
    }

    if (errorM.hasError) {
        errorM.hasError = setError()
    }

    var popUpImage by remember { mutableStateOf(false) }
    if (popUpImage) PhotoPopUp(
        cancel = { popUpImage = false },
        changeImage = {
            alreadyChange = true
            values.photo = it
            popUpImage = false
        }
    )

    var receiptIsEmpty by remember { mutableStateOf(false) }
    if (receiptIsEmpty) ReceiptIsEmpty(
        addPhoto = { popUpImage = true; receiptIsEmpty = false },
        doLater = { receiptIsEmpty = false; values.saveChange() },
        dismiss = { receiptIsEmpty = false }
    )

    val currentDestination = navController.currentDestination?.route ?: ""

    Scaffold(
        topBar = { Helper.TopBar(currentDestination) },
        bottomBar = {
            Helper.BottomBar(currentDestination) {
                if (successfully || !alreadyChange) {
                    navController.navigate(it)
                } else {
                    unsavedChanges = true
                    unsavedChangesAct = it
                }
            }
        },
        containerColor = Helper.Color.Black,
        contentColor = Helper.Color.White
    ) {
        Column(
            modifier = Modifier
                .padding(it)
                .fillMaxSize()
        ) {
            if (successfully) {
                EmptyList(
                    ico = painterResource(R.drawable.ico_list),
                    text1 = "Receipt added successfully!",
                    text2 = "Now you can add more receipts",
                    textButton = "Add new reciept",
                    clickButton = { navController.navigate(Route.ADD_RECEIPT) }
                )

            } else {
                Column(
                    modifier = Modifier
                        .padding(16.dp)
                        .verticalScroll(rememberScrollState())
                ) {
                    ImageField(
                        currentUri = values.photo,
                        popUpImage = { popUpImage = true }
                    )
                    Spacer(Modifier.size(16.dp))
                    SelectedField(
                        value = values.expensesType,
                        setValue = {
                            alreadyChange = true
                            values.expensesType = it
                                   },
                        itemsList = Helper.receiptTypes,
                        label = "Expenses Type",
                        placeholder = "Select Type",
                        isError = errorM.expensesType,
                        errorText = "Please select your expenses type"
                    )
                    Spacer(Modifier.size(16.dp))
                    SelectedField(
                        value = values.budget,
                        setValue = {
                            alreadyChange = true
                            values.budget = it
                                   },
                        itemsList = budgets!!.map { it.budgetNumber }.toTypedArray(),
                        valueWrap = { budgetNumber ->
                            var value = ""
                            budgets!!.forEach {
                                if (budgetNumber == it.budgetNumber) {
                                    value = it.budgetNumberName
                                }
                            }
                            return@SelectedField value
                        },
                        label = "Budget",
                        placeholder = "Select Budget",
                        isError = errorM.budget,
                        errorText = "Please select a budget"
                    )
                    Spacer(Modifier.size(16.dp))
                    Row(
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        OwnTextField(
                            value = values.amount,
                            changeValue = {
                                alreadyChange = true
                                values.amount = it
                                          },
                            label = "Amount",
                            prefix = Helper.getCurrencySymbol(values.currency),
                            placeholder = "0.00",
                            type = "Double",
                            w = 0.67f,
                            isError = errorM.amount,
                            errorText = "Please enter amount"
                        )
                        Spacer(Modifier.fillMaxWidth(0.1f))
                        SelectedField(
                            label = "Currency",
                            value = values.currency,
                            itemsList = Helper.getAvailableCurrencies(),
                            setValue = {
                                alreadyChange = true
                                values.currency = it
                                       },
                            isError = errorM.currency,
                        )
                    }
                    Spacer(Modifier.size(16.dp))
                    OwnTextField(
                        value = values.numberOfPeople,
                        changeValue = {
                            alreadyChange = true
                            values.numberOfPeople = it
                                      },
                        label = "Number of people",
                        placeholder = "Number of people",
                        type = "Int",
                        isError = errorM.numberOfPeople,
                        errorText = "Please enter number of people"
                    )
                    Spacer(Modifier.size(16.dp))
                    DateField(
                        value = values.payingDate,
                        label = "Paying date",
                        setValue = {
                            alreadyChange = true
                            values.payingDate = it
                                   },
                        isError = errorM.payingDate,
                        errorText = "Please select your paying date"
                    )
                    Spacer(Modifier.size(16.dp))
                    OwnTextMultiLineField(
                        value = values.description,
                        changeValue = {
                            alreadyChange = true
                            values.description = it
                                      },
                        label = "Description (Optional)",
                        placeholder = "Enter you description here"
                    )
                    Helper.HDivider()
                    Helper.ButtonBlue(
                        onClick = {
                            errorM.hasError = setError()
                            if (!errorM.hasError) {
                                if (Uri.EMPTY.equals(values.photo)) {
                                    receiptIsEmpty = true
                                } else {
                                    values.saveChange()
                                }
                            }
                        },
                        text = { Helper.Text("Save a receipt") }
                    )
                }
            }
        }
    }
}