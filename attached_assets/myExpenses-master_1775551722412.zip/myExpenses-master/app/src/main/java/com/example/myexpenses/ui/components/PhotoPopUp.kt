package com.example.myexpenses.ui.components

import android.annotation.SuppressLint
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.staggeredgrid.LazyVerticalStaggeredGrid
import androidx.compose.foundation.lazy.staggeredgrid.StaggeredGridCells
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.BasicAlertDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.core.net.toUri
import androidx.lifecycle.viewmodel.compose.viewModel
import coil.compose.rememberImagePainter
import com.example.myexpenses.R
import com.example.myexpenses.data.Helper
import com.example.myexpenses.ui.AppViewModelProvider
import com.example.myexpenses.ui.screens.CameraScreen
import com.example.myexpenses.ui.screens.models.MediaStoreModel
import java.io.File

@Composable
fun ImageField (
    currentUri:String,
    popUpImage: ()->Unit,
    title:String? = "Receipt"
) {
    ImageField(
        if (currentUri.isEmpty()) Uri.EMPTY else File(currentUri).toUri(),
        popUpImage,
        title
    )
}

@Composable
fun ImageField (
    currentUri:Uri,
    popUpImage: ()->Unit,
    title:String? = "Receipt"
){
    var bigImage by remember { mutableStateOf(false) }
    if (title != null)Helper.Text(text = title)
    if (Uri.EMPTY.equals(currentUri)) {
        Helper.ButtonBlue(
            { popUpImage() },
            {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(0.dp, 28.dp),
                    verticalArrangement = Arrangement.Center,
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Icon(
                        tint = Helper.Color.White,
                        modifier = Modifier.size(32.dp),
                        painter = painterResource(R.drawable.ico_photo),
                        contentDescription = ""
                    )

                    Helper.Text(
                        text = "Add a receipt photo",
                        modifier = Modifier.drawBehind {
                            val strokeWidthPx = 1.dp.toPx()
                            val verticalOffset = size.height - 2.sp.toPx()
                            drawLine(
                                color = Color(0xFFF3F3F3),
                                strokeWidth = strokeWidthPx,
                                start = Offset(0f, verticalOffset),
                                end = Offset(size.width, verticalOffset)
                            )
                        }
                    )
                }
            }
        )
    } else {
        val _h = if (bigImage) 380.dp else 113.dp
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(_h)
                .padding(0.dp)
                .clip(Helper.bRadius),
        ) {
            Column {
                Image(
                    painter = rememberImagePainter(currentUri),
                    contentDescription = null,
                    contentScale = if (bigImage) ContentScale.FillHeight else ContentScale.Crop,
                    modifier = Modifier.fillMaxSize().clickable {
                        bigImage = !bigImage
                    }
                )
            }

            Row(
                verticalAlignment = Alignment.Bottom,
                horizontalArrangement = Arrangement.End,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(_h)
                    .padding(8.dp)
            ) {
                IconButton(
                    modifier = Modifier
                        .clip(Helper.bRadius)
                        .background(Helper.Color.Black3C)
                        .size(40.dp),
                    onClick = { popUpImage() }
                ) {
                    Icon(
                        modifier = Modifier.size(24.dp),
                        painter = painterResource(R.drawable.ico_photo),
                        contentDescription = "",
                        tint = Helper.Color.White
                    )
                }
            }
        }
    }
}





@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PhotoPopUp(
    cancel: () -> Unit,
    changeImage: (Uri) -> Unit,
    module: Int = 0,
    viewMedia: MediaStoreModel = viewModel(factory = AppViewModelProvider.Factory)
) {
    var model: Int by remember { mutableIntStateOf(module) }

    val imagePicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent(),
        onResult = {
            it?.let { changeImage(it) }
        }
    )
    when (model) {
        0 -> {
            BasicAlertDialog(
                modifier = Helper.modifierAlert,
                onDismissRequest = { cancel() },
            ) {
                Column(
                    modifier = Modifier.padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    content = {
                        Helper.TextH2(text = "Add a receipt")
                        Helper.HDivider()
                        Helper.ButtonBlue(onClick = { model = 1 }, text = { Helper.Text("Take a picture") })
                        Helper.ButtonGrey3C(
                            onClick = { imagePicker.launch("image/*") },
                            text = { Helper.Text("Add from gallery") }
                        )
                        if ( viewMedia.getAllFromLocal().isNotEmpty() ) {
                            Helper.ButtonGrey3C(
                                onClick = { model = 2 },
                                text = { Helper.Text("Add from local App store") }
                            )
                        }
                    }
                )
            }
        }
        1 -> {
            Dialog(
                properties = DialogProperties(usePlatformDefaultWidth = false),
                onDismissRequest = {}
            ) {
                CameraScreen(
                    cancel = { cancel() },
                    returnUri = { changeImage(it) },
                )
            }
        }
        2 -> {
            Dialog(
                properties = DialogProperties(usePlatformDefaultWidth = false),
                onDismissRequest = { cancel() }
            ) {
                val images = viewMedia.getAllFromLocal()
                if (images.isEmpty()) {
                    Helper.TextH2( text = "None items" )
                    Helper.HDivider()
                    Helper.ButtonGrey(onClick = { cancel() }, text = { Helper.Text("Cancel") })
                } else {
                    Gallery(
                        images = images,
                        changeImage = changeImage,
                        cancel = { cancel() }
                    )
                }
            }
        }
        3-> {
            Dialog(
                properties = DialogProperties(usePlatformDefaultWidth = false),
                onDismissRequest = {}
            ) {
                CameraScreen(
                    cancel = { cancel() },
                    returnUri = { changeImage(it) },
                )
            }
        }
    }
}

@SuppressLint("UnusedMaterial3ScaffoldPaddingParameter")
@Composable
private fun Gallery(
    images: List<Uri>,
    changeImage: (Uri) -> Unit,
    cancel:() -> Unit
) {
    var selected by remember { mutableIntStateOf(-1) }
    Scaffold(
        topBar = {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Helper.Color.Black2C)
                    .padding(16.dp),
                horizontalArrangement = Arrangement.End
            ) {
                IconButton(onClick = { cancel() }) {
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = "Close",
                        tint = Color(0xFFF3F3F3)
                    )
                }
            }
        },
        bottomBar = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Helper.Color.Black2C)
                    .padding(20.dp),
            ) {
                Helper.ButtonBlue(
                    onClick = { changeImage(images[selected]) },
                    text = { Helper.Text("Select") },
                    enabled = selected != -1
                )
                Helper.ButtonGrey(onClick = { cancel() }, text = { Helper.Text("Cancel") })
            }
        },
    ) { contentPadding ->
        LazyVerticalStaggeredGrid(
            modifier = Modifier
                .fillMaxSize()
                .background(Helper.Color.Black2C)
                .padding(top = 40.dp, bottom = 80.dp),
            contentPadding = contentPadding,
            columns = StaggeredGridCells.Fixed(3),
            verticalItemSpacing = 4.dp,
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            items(images.count()) { index ->
                Box {
                    Image(
                        painter = rememberImagePainter(images[index]),
                        contentDescription = null,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier
                            .fillMaxSize()
                            .height(200.dp)
                            .clickable {
                                selected = index
                            }
                    )
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 5.dp, end = 5.dp),
                        horizontalArrangement = Arrangement.End,
                    ) {
                        Icon(
                            modifier = Modifier
                                .size(30.dp)
                                .background(Helper.Color.Black3C)
                                .padding(7.dp),
                            imageVector = if (selected == index) Icons.Default.Check else Icons.Default.Share,
                            contentDescription = "",
                            tint = Helper.Color.White
                        )
                    }
                }
            }
        }
    }
}