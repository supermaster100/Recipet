package com.example.myexpenses

import android.app.Application
import com.example.myexpenses.data.CMediaStore
import com.example.myexpenses.data.InventoryDatabase
import com.example.myexpenses.data.db.ExpenseDao

class InventoryApplication : Application() {
    val expenseDao: ExpenseDao by lazy {
        InventoryDatabase.getDatabase(this).itemDao()
    }
    lateinit var media: CMediaStore
    override fun onCreate() {
        super.onCreate()

        media = CMediaStore(this)
    }
}
