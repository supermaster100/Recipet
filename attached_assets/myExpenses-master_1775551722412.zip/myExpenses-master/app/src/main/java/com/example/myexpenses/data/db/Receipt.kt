package com.example.myexpenses.data.db

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "Receipts")
data class Receipt(
    @PrimaryKey(autoGenerate = true)
    val id: Int = 0,
    val photo: String,
    val expensesType: String,
    val budget: String,
    val amount: String,
    val currency: String,
    val numberOfPeople: String,
    val payingDate: Long,
    val description: String = "",
    val export: Long = -1,
    val delPhoto: Boolean = false,
    val status: Boolean = true
)