package com.example.myexpenses.ui.screens.more

import android.annotation.SuppressLint
import androidx.compose.foundation.interaction.Interaction
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.PressInteraction
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material3.BasicAlertDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.myexpenses.data.Helper
import com.example.myexpenses.ui.components.OwnTextField
import com.example.myexpenses.ui.components.SelectedField
import kotlinx.coroutines.channels.BufferOverflow
import kotlinx.coroutines.flow.MutableSharedFlow
import java.time.LocalDateTime
import java.time.Year
import java.time.format.DateTimeFormatter

@OptIn(ExperimentalMaterial3Api::class)
@SuppressLint("RememberReturnType")
@Composable
fun MonthYearField(
    value: String = "",
    changeValue: (String) -> Unit = {},
    isError: Boolean = false,
    errorText: String = "Missing Field",
) {
    var popMonthYear by remember { mutableStateOf(false) }

    if (popMonthYear) {
        BasicAlertDialog(
            modifier = Helper.modifierAlert,
            onDismissRequest = { popMonthYear = false },
        ) {
            var current by remember {
                mutableStateOf(
                    if (value.isEmpty())
                        LocalDateTime.now().format(DateTimeFormatter.ofPattern("MM/yyyy"))
                            .split("/")
                    else
                        value.split("/")
                )
            }

            Column(modifier = Modifier.padding(16.dp)) {
                Row {
                    SelectedField(
                        value = current[0],
                        itemsList = Array(12) { i -> (i + 1).toString().padStart(2, '0') },
                        setValue = { value -> current = listOf(value, current[1]) },
                        label = "Month",
                        w = 0.5f
                    )
                    Spacer(Modifier.size(12.dp))
                    SelectedField(
                        value = current[1],
                        itemsList = Array(20) { i -> (Year.now().value + i - 5).toString() },
                        setValue = { value -> current = listOf(current[0], value) },
                        label = "Year"
                    )
                }
                Spacer(Modifier.size(20.dp))
                Helper.ButtonBlue(
                    onClick = {
                        popMonthYear = false
                        changeValue("${current[0]}/${current[1]}")
                    }, text = { Helper.Text("OK") })
            }
        }
    }
    OwnTextField(
        interactionSource = remember {
            object : MutableInteractionSource {
                override val interactions = MutableSharedFlow<Interaction>(
                    extraBufferCapacity = 16,
                    onBufferOverflow = BufferOverflow.DROP_OLDEST,
                )

                override suspend fun emit(interaction: Interaction) {
                    when (interaction) {
                        is PressInteraction.Press -> {
                            popMonthYear = true
                        }
                    }
                    interactions.emit(interaction)
                }

                override fun tryEmit(interaction: Interaction): Boolean {
                    return interactions.tryEmit(interaction)
                }
            }
        },
        value = value,
        label = "Month / Year",
        placeholder = "MM/YYYY",
        isError = isError,
        errorText = errorText,
        type = "monthYearField"
    )
}