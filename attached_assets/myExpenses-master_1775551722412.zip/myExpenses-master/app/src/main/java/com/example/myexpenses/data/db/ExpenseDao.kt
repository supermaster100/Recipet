package com.example.myexpenses.data.db

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update

@Dao
interface ExpenseDao {
    /*General*/
    @Query("SELECT * from Generals LIMIT 1")
    suspend fun getGeneral(): List<General>

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertGeneral(general: General): Long

    @Update
    suspend fun updateGeneral(general: General)

    /*Budget*/
    @Query("SELECT * from Budgets WHERE status = true")
    suspend fun getBudgets(): List<Budget>

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertBudget(budget: Budget): Long

    @Query("DELETE FROM Budgets WHERE id = :id")
    suspend fun deleteBudget(id: Long)


    /*Receipt*/
    @Query("SELECT * from Receipts where id = :id")
    suspend fun getReceipt(id: Long): Receipt

    @Query("SELECT currency from Receipts ORDER BY ID DESC LIMIT 1")
    suspend fun getLastReceipt(): List<String>

    @Query("SELECT * from Receipts WHERE status = 1")
    suspend fun getReceipts(): List<Receipt>

    @Query("UPDATE Receipts SET status = 0, export =:tms WHERE status = 1")
    suspend fun deleteReceipts(tms: Long)

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertReceipt(receipt: Receipt)

    @Update
    suspend fun updateReceipt(receipt: Receipt)


    /*Exchange*/
    @Query("SELECT * from Exchanges where id = :id")
    fun getExchange(id: Long): Exchange

    @Query("SELECT * from Exchanges WHERE status = 1")
    suspend fun getExchanges(): List<Exchange>

    @Query("UPDATE Exchanges SET status = 0, export =:tms WHERE status = 1")
    suspend fun deleteExchanges(tms: Long)

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertExchange(exchange: Exchange)

    @Update
    suspend fun updateExchange(exchange: Exchange)

    /*Travel*/
    @Query("SELECT * from Legs WHERE status = 1 LIMIT 1")
    suspend fun getLegs(): List<Leg>


    @Update
    suspend fun updateLegs(leg:Leg)

    @Query("UPDATE Legs SET status = 0 WHERE status = 1")
    suspend fun deleteLegs()

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertLeg(leg: Leg): Long

    @Query("SELECT * from Travels where lId = :lId ORDER BY num")
    suspend fun getTravels(lId: Long): List<Travel>

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertTravels(travels: List<Travel>)

    @Update
    suspend fun updateTravel(exchange: Travel)

    @Query("UPDATE Travels SET export = :tms WHERE lId = :id")
    suspend fun updateTravels(id: Long, tms: Long)
}
