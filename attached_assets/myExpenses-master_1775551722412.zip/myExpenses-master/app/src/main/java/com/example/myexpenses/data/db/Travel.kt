package com.example.myexpenses.data.db

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "Travels")
data class Travel(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val lId: Long,
    val num: Int,
    var departure: String,
    var destination: String,
    var departureDate: Long,
    var returnDate: Long,
    var budget: String,
    var placeOfStaying: String,
    var nights: String,
    var arbitraryLocation: Boolean,
    var ratePerNight: String,
    var currencyPN: String,
    var breakfast: Boolean,
    var paymentMethod: String,
    var hotelExtraFees: String,
    var currencyHEF: String,
    var description: String,
    var photo: String,
    val export: Long = -1,
    val delPhoto: Boolean = false,
)