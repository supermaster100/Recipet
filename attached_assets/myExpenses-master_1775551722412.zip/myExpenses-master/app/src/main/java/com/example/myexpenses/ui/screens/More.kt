package com.example.myexpenses.ui.screens

import android.annotation.SuppressLint
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.painter.Painter
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.example.myexpenses.R
import com.example.myexpenses.data.Helper
import com.example.myexpenses.data.Route
import com.example.myexpenses.nonScaledSp
import com.example.myexpenses.ui.components.UnsavedChanges
import com.example.myexpenses.ui.screens.more.AboutApp
import com.example.myexpenses.ui.screens.more.DownloadReport
import com.example.myexpenses.ui.screens.more.GeneralDataSettings

@SuppressLint("MutableCollectionMutableState", "CoroutineCreationDuringComposition")
@Composable
fun More(
    navController: NavController,
) {
    var popUpAbout by remember { mutableStateOf(false) }
    var generalDataSettings by remember { mutableStateOf(false) }
    var downloadExpensesReport by remember { mutableStateOf(false) }
    var editMod by remember { mutableStateOf(false) }

    var unsavedChanges by remember { mutableStateOf(false) }
    var unsavedChangesAct by remember { mutableStateOf("") }
    if (unsavedChanges) UnsavedChanges(
        back = {
            if (unsavedChangesAct == "Back") {
                navController.navigate(Route.MORE)
            } else {
                navController.navigate(unsavedChangesAct)
            }
            unsavedChanges = false
            unsavedChangesAct = ""
        },
        dismiss = { unsavedChanges = false; unsavedChangesAct = "" }
    )

    if (popUpAbout) {
        AboutApp { popUpAbout = false }
    }

    val currentDestination = navController.currentDestination?.route ?: ""

    Scaffold(
        topBar = {
            if (generalDataSettings) {
                Helper.TopBar(
                    "General data settings",
                    row = {
                        if (editMod) {
                            unsavedChanges = true
                            unsavedChangesAct = "Back"
                        } else {
                            generalDataSettings = false
                        }
                    }
                )
            } else if (downloadExpensesReport) {
                Helper.TopBar(
                    "Download expenses report",
                    row = {
                        downloadExpensesReport = false
                    }
                )
            } else {
                Helper.TopBar(currentDestination)
            }
        },
        bottomBar = {
            Helper.BottomBar(currentDestination) {
                if ( editMod ) {
                    unsavedChanges = true
                    unsavedChangesAct = it
                } else
                    navController.navigate(it)
            }
        },
        containerColor = Helper.Color.Black,
        contentColor = Helper.Color.White
    ) { it ->
        Column(
            modifier = Modifier
                .padding(it)
                .fillMaxSize()
        ) {
            if ( generalDataSettings ){
                GeneralDataSettings(setEditMod = { edit -> editMod = edit })
            } else if (downloadExpensesReport){
                DownloadReport(
                    navController = navController,
                    back = {
                        downloadExpensesReport = false
                    },
                )
            } else {
                MoreScreenButton(
                    icon = painterResource(R.drawable.ico_download_button),
                    text = "Download expenses report",
                    onClick = {downloadExpensesReport = true},
                )
                MoreScreenButton(
                    icon = painterResource(R.drawable.ico_general_button),
                    text = "General data settings",
                    onClick = { generalDataSettings = true },
                )
                MoreScreenButton(
                    icon = painterResource(R.drawable.ico_about_button),
                    text = "About App",
                    onClick = { popUpAbout = true },
                )
            }
        }
    }
}

@Composable
fun MoreScreenButton(
    onClick: () -> Unit,
    icon: Painter,
    text: String
){
    Button(
        modifier = Modifier.padding(16.dp, 16.dp, 16.dp, 12.dp).fillMaxWidth(),
        shape =  RoundedCornerShape(8.dp),
        colors = ButtonDefaults.buttonColors(
            containerColor = Color(0xFF2C2C2C),
            contentColor = Color(0xFFF3F3F3),
            disabledContainerColor = Color(0x0F2C2C2C),
            disabledContentColor = Color(0x0FF3F3F3),
        ),
        onClick = { onClick() }
    ) {
        Row(
            modifier = Modifier.padding(top = 16.dp, bottom = 16.dp).fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Absolute.Left
        ) {
            Icon(
                modifier = Modifier.padding(end = 8.dp),
                painter = icon,
                contentDescription = ""
            )
            Text(
                modifier = Modifier.weight(1f),
                text = text,
                fontSize = 16.sp.nonScaledSp,
                fontWeight = FontWeight(500)
            )
            Icon(
                painter = painterResource(R.drawable.ico_row_right),
                contentDescription = ""
            )
        }
    }
}