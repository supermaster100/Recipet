package com.example.myexpenses.ui

import androidx.lifecycle.ViewModelProvider.AndroidViewModelFactory
import androidx.lifecycle.viewmodel.CreationExtras
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.example.myexpenses.InventoryApplication
import com.example.myexpenses.ui.screens.models.AddExchangeModule
import com.example.myexpenses.ui.screens.models.AddReceiptModule
import com.example.myexpenses.ui.screens.models.AddTravelModule
import com.example.myexpenses.ui.screens.models.BudgetModule
import com.example.myexpenses.ui.screens.models.DownloadReportModule
import com.example.myexpenses.ui.screens.models.GeneralModule
import com.example.myexpenses.ui.screens.models.MediaStoreModel

object AppViewModelProvider {
    val Factory = viewModelFactory {
        initializer {
            GeneralModule(InventoryApplication().expenseDao)
        }
        initializer {
            BudgetModule(InventoryApplication().expenseDao)
        }
        initializer {
            AddReceiptModule(InventoryApplication().expenseDao)
        }
        initializer {
            AddExchangeModule(InventoryApplication().expenseDao)
        }
        initializer {
            AddTravelModule(InventoryApplication().expenseDao)
        }
        initializer {
            DownloadReportModule(InventoryApplication().expenseDao)
        }

/*************************************************************/
        initializer {
            MediaStoreModel(InventoryApplication().media)
        }
    }
}
fun CreationExtras.InventoryApplication(): InventoryApplication =
    (this[AndroidViewModelFactory.APPLICATION_KEY] as InventoryApplication)
