package com.example.myexpenses.ui.components

import androidx.compose.foundation.layout.Column
import androidx.compose.material3.BasicAlertDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.text.style.TextAlign
import com.example.myexpenses.data.Helper

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ReceiptIsEmpty(
    addPhoto: () -> Unit,
    doLater: () -> Unit,
    dismiss: () -> Unit
) {
    BasicAlertDialog(
        modifier = Helper.modifierAlert,
        onDismissRequest = { dismiss() },
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            content = {
                Helper.TextH2("Receipt is empty", TextAlign.Center)
                Helper.HDivider()
                Helper.Text("Seems you didn’t add a photo of your receipt. You can add a photo now or do it later.")
                Helper.HDivider()
                Helper.ButtonBlue(onClick = { addPhoto() }, text = { Helper.Text("Add a photo") })
                Helper.ButtonGrey(onClick = { doLater() }, text = { Helper.Text("Do it later") })
            }
        )
    }
}

