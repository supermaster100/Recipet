package com.example.myexpenses.ui.screens.travel

import android.annotation.SuppressLint
import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Card
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.LocalMinimumInteractiveComponentEnforcement
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.MutableState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavController
import com.example.myexpenses.R
import com.example.myexpenses.data.Helper
import com.example.myexpenses.data.Route
import com.example.myexpenses.data.db.Budget
import com.example.myexpenses.data.db.Leg
import com.example.myexpenses.data.db.Travel
import com.example.myexpenses.nonScaledSp
import com.example.myexpenses.ui.AppViewModelProvider
import com.example.myexpenses.ui.components.DateField
import com.example.myexpenses.ui.components.ImageField
import com.example.myexpenses.ui.components.OwnTextField
import com.example.myexpenses.ui.components.OwnTextMultiLineField
import com.example.myexpenses.ui.components.PhotoPopUp
import com.example.myexpenses.ui.components.SelectedField
import com.example.myexpenses.ui.screens.models.AddTravelModule
import com.example.myexpenses.ui.screens.models.MediaStoreModel
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@SuppressLint("CoroutineCreationDuringComposition", "MutableCollectionMutableState")
@Composable
fun AddTravel (
    navController: NavController,
    alreadyChange: () -> Unit = {},
    travel: Travel? = null,
    travelModel: AddTravelModule = viewModel(factory = AppViewModelProvider.Factory),
    viewMedia: MediaStoreModel = viewModel(factory = AppViewModelProvider.Factory)
) {
    var travelType: String by remember { mutableStateOf("") }
    val country = viewMedia.getCountryFromJson()[0]
    var destination: Int by remember { mutableIntStateOf(0) }
    val destinations:ArrayList<TravelD> by remember { mutableStateOf(arrayListOf()) }
    val coroutineScope = rememberCoroutineScope()
    var budgets: List<Budget>? by remember { mutableStateOf(null) }

    if (budgets == null) {
        coroutineScope.launch {
            budgets = travelModel.getBudgets()
        }
        return
    }

    if (destinations.size < destination + 1) {
        destinations.add(
            TravelD(
                departure = remember { mutableStateOf(
                    if (destination > 0)
                        destinations[destination -1].destination.value
                    else if (travel != null)
                        travel.departure
                    else ""
                ) },
                destination = remember { mutableStateOf("") },
                departureDate = remember { mutableStateOf(
                    if (destination > 0)
                        destinations[destination -1].returnDate.value
                    else if (travel != null)
                        travel.returnDate
                    else null
                ) },
                returnDate = remember { mutableStateOf(null) },
                budget = remember { mutableStateOf("") },
                placeOfStaying = remember { mutableStateOf("") },
                nights = remember { mutableStateOf("") },
                arbitraryLocation = remember { mutableStateOf(false) },
                ratePerNight = remember { mutableStateOf("") },
                currencyPN = remember { mutableStateOf("") },
                breakfast = remember { mutableStateOf(false) },
                paymentMethod = remember { mutableStateOf("") },
                hotelExtraFees = remember { mutableStateOf("") },
                currencyHEF = remember { mutableStateOf("") },
                description = remember { mutableStateOf("") },
                photo = remember { mutableStateOf(Uri.EMPTY) }
            )
        )
    }

    val saveTravel = {
        coroutineScope.launch {
            val lId = if (travel == null)
                travelModel.insertLeg(Leg(id = 0, type = travelType))
            else
                travel.lId

            val travels = mutableListOf<Travel>()
            destinations.forEachIndexed { index, travelD ->
                travels += Travel(
                    id = 0,
                    lId = lId,
                    num = if (travel == null) index else travel.num + 1,
                    departure = travelD.departure.value,
                    destination = travelD.destination.value,
                    departureDate = travelD.departureDate.value!!,
                    returnDate = travelD.returnDate.value!!,
                    budget = travelD.budget.value,
                    placeOfStaying = travelD.placeOfStaying.value,
                    nights = travelD.nights.value,
                    arbitraryLocation = travelD.arbitraryLocation.value,
                    ratePerNight = travelD.ratePerNight.value,
                    currencyPN = travelD.currencyPN.value,
                    breakfast = travelD.breakfast.value,
                    paymentMethod = travelD.paymentMethod.value,
                    hotelExtraFees = travelD.hotelExtraFees.value,
                    currencyHEF = travelD.currencyHEF.value,
                    description = travelD.description.value,
                    photo = viewMedia.saveToLocal(travelD.photo.value.toString())
                )
            }
            travelModel.insert(travels.toList())
            navController.navigate(Route.TRAVEL)
        }
    }

    val errorM = object {
        var departure: Boolean by remember { mutableStateOf(false) }
        var destination: Boolean by remember { mutableStateOf(false) }
        var departureDate: Boolean by remember { mutableStateOf(false) }
        var returnDate: Boolean by remember { mutableStateOf(false) }
        var budget: Boolean by remember { mutableStateOf(false) }
        var placeOfStaying: Boolean by remember { mutableStateOf(false) }
        var nights: Boolean by remember { mutableStateOf(false) }

        var ratePerNight: Boolean by remember { mutableStateOf(false) }
        var currencyPN: Boolean by remember { mutableStateOf(false) }
        var paymentMethod: Boolean by remember { mutableStateOf(false) }

        var hasError: Boolean by remember { mutableStateOf(false) }
    }

    val setError = fun(): Boolean {
        errorM.departure = destinations[destination].departure.value.isEmpty() || ! country.contains(destinations[destination].departure.value)
        errorM.destination = destinations[destination].destination.value.isEmpty() || ! country.contains(destinations[destination].destination.value)
        errorM.departureDate = destinations[destination].departureDate.value == null
        errorM.returnDate = destinations[destination].returnDate.value == null
        errorM.budget = destinations[destination].budget.value.isEmpty()
        errorM.placeOfStaying = destinations[destination].placeOfStaying.value.isEmpty()
        errorM.nights = destinations[destination].nights.value.isEmpty()

        errorM.ratePerNight = !destinations[destination].arbitraryLocation.value && destinations[destination].ratePerNight.value.isEmpty()
        errorM.currencyPN = !destinations[destination].arbitraryLocation.value && destinations[destination].currencyPN.value.isEmpty()
        errorM.paymentMethod = !destinations[destination].arbitraryLocation.value && destinations[destination].paymentMethod.value.isEmpty()

        return errorM.departure || errorM.destination || errorM.departureDate || errorM.returnDate || errorM.budget || errorM.placeOfStaying
                || errorM.nights || errorM.ratePerNight || errorM.currencyPN || errorM.paymentMethod
    }

    if (errorM.hasError) {
        errorM.hasError = setError()
    }

    var popUpImage by remember { mutableStateOf(false) }
    if (popUpImage) PhotoPopUp(
        cancel = { popUpImage = false },
        changeImage = {
            alreadyChange()
            destinations[destination].photo.value = it
            popUpImage = false
        }
    )

    val scrollState = rememberScrollState()

    Column(
        modifier = Modifier
            .padding(16.dp)
            .verticalScroll(scrollState)
    ) {
        if (travel == null) {
            SelectedField(
                label = "Travel Type",
                enabled = destinations.size <= 1,
                value = travelType,
                placeholder = "Select travel type",
                itemsList = Helper.travelTypes,
                setValue = {
                    travelType = it
                },
            )
        }

        if (travelType.isNotEmpty() || travel != null) {
            if (travelType == Helper.travelTypes[1]) {
                Spacer(Modifier.size(16.dp))
                Row(
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(Helper.bRadius)
                        .background(Helper.Color.Blue)
                        .padding(16.dp)

                ){
                    if (destination > 0) {
                        Icon(
                            modifier = Modifier.clickable {
                                errorM.hasError = setError()
                                if (!errorM.hasError) {
                                    destination -= 1
                                }
                            },
                            painter = painterResource(R.drawable.ico_row_left),
                            contentDescription = ""
                        )
                    } else {
                        Text("")
                    }
                    Text("Destination ${destination+1}")
                    if (destinations.size > destination + 1) {
                        Icon(
                            modifier = Modifier.clickable {
                                errorM.hasError = setError()
                                if (!errorM.hasError) {
                                    destination += 1
                                }
                            },
                            painter = painterResource(R.drawable.ico_row_right),
                            contentDescription = ""
                        )
                    } else {
                        Text("")
                    }
                }

            }
            Spacer(Modifier.size(16.dp))
            TravelAutoComplete(
                departureValue = destinations[destination].departure.value,
                destinationValue = destinations[destination].destination.value,
                setDepartureValue = {
                    alreadyChange()
                    destinations[destination].departure.value = it
                                    },
                setDestinationValue = {
                    alreadyChange()
                    destinations[destination].destination.value = it
                                      },
                itemsList = country,
                isDepartureError = errorM.departure,
                isDestinationError = errorM.destination
            )
            Spacer(Modifier.size(16.dp))
            Row(
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Top
            ) {
                DateField(
                    value = destinations[destination].departureDate.value,
                    label = "Departure date",
                    setValue = {
                        alreadyChange()
                        destinations[destination].departureDate.value = it
                        if (it != null && destinations[destination].returnDate.value != null){
                            val f = (it - destinations[destination].returnDate.value!! )/ 86400000
                            destinations[destination].nights.value = (if (f >= 0) f else f * -1).toString()
                        }
                    },
                    isError = errorM.departureDate,
                    errorText = "Please select your departure date",
                    w = 0.44f
                )
                Column {
                    Helper.Text(text = " ")
                    Icon(
                        modifier = Modifier.fillMaxWidth(0.21f).padding(top = 10.dp),
                        painter = painterResource(R.drawable.ico_calendar),
                        contentDescription = ""
                    )
                }
                DateField(
                    value = destinations[destination].returnDate.value,
                    label = "Return date",
                    setValue = {
                        alreadyChange()
                        destinations[destination].returnDate.value = it
                        if (it != null && destinations[destination].departureDate.value != null){
                            val f = (it - destinations[destination].departureDate.value!!)/ 86400000
                            destinations[destination].nights.value = (if (f >= 0) f else f * -1).toString()
                        }
                    },
                    isError = errorM.returnDate,
                    errorText = "Please select your return date",
                    w = 1f
                )
            }
            Helper.HDivider()
            SelectedField(
                value = destinations[destination].budget.value,
                setValue = {
                    alreadyChange()
                    destinations[destination].budget.value = it
                           },
                itemsList = budgets!!.map { it.budgetNumber }.toTypedArray(),
                valueWrap = { budgetNumber ->
                    var value = ""
                    budgets!!.forEach {
                        if (budgetNumber == it.budgetNumber) {
                            value = it.budgetNumberName
                        }
                    }
                    return@SelectedField value
                },
                label = "Budget",
                placeholder = "Select Budget",
                isError = errorM.budget,
                errorText = "Please select a budget"
            )
            Spacer(Modifier.size(16.dp))
            Row(
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                OwnTextField(
                    label = "Place of staying",
                    placeholder = "Place of staying",
                    value = destinations[destination].placeOfStaying.value,
                    changeValue = {
                        alreadyChange()
                        destinations[destination].placeOfStaying.value = it
                                  },
                    w = 0.67f,
                    isError = errorM.placeOfStaying,
                    errorText = "Please select your place of staying"
                )
                Spacer(Modifier.fillMaxWidth(0.1f))
                OwnTextField(
                    label = "Nights",
                    placeholder = "Nights",
                    value = destinations[destination].nights.value,
                    changeValue = {
                        alreadyChange()
                        destinations[destination].nights.value = it
                                  },
                    type = "Int",
                    isError = errorM.nights,
                    errorText = "Please enter Nights"
                )
            }
            Spacer(Modifier.size(16.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Start
            ) {
                CompositionLocalProvider(LocalMinimumInteractiveComponentEnforcement provides false) {
                    Checkbox(
                        checked = destinations[destination].arbitraryLocation.value,
                        onCheckedChange = {
                            alreadyChange()
                            destinations[destination].arbitraryLocation.value = it
                        },
                        colors = CheckboxDefaults.colors().copy(
                            checkedCheckmarkColor = Helper.Color.White,
                            checkedBoxColor = Helper.Color.Blue,
                            uncheckedBoxColor = Helper.Color.Black3C,
                            checkedBorderColor = Helper.Color.White10,
                            uncheckedBorderColor = Helper.Color.White10
                        )
                    )
                }
                Spacer(Modifier.size(10.dp))
                Helper.Text("I choose an arbitrary location*")
            }

            if (!destinations[destination].arbitraryLocation.value) {
                Spacer(Modifier.size(16.dp))
                Row(
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    OwnTextField(
                        value = destinations[destination].ratePerNight.value,
                        changeValue = {
                            alreadyChange()
                            destinations[destination].ratePerNight.value = it
                                      },
                        label = "Price per night",
                        prefix = Helper.getCurrencySymbol(destinations[destination].currencyPN.value),
                        placeholder = "0.00",
                        type = "Double",
                        w = 0.67f,
                        isError = errorM.ratePerNight,
                        errorText = "Please enter price per night"
                    )
                    Spacer(Modifier.fillMaxWidth(0.1f))
                    SelectedField(
                        label = "Currency",
                        value = destinations[destination].currencyPN.value,
                        itemsList = Helper.getAvailableCurrencies(),
                        setValue = {
                            alreadyChange()
                            destinations[destination].currencyPN.value = it
                                   },
                        isError = errorM.currencyPN
                    )
                }
                Spacer(Modifier.size(16.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Start
                ) {
                    CompositionLocalProvider(LocalMinimumInteractiveComponentEnforcement provides false) {
                        Checkbox(
                            checked = destinations[destination].breakfast.value,
                            onCheckedChange = {
                                alreadyChange()
                                destinations[destination].breakfast.value = it
                                              },
                            colors = CheckboxDefaults.colors().copy(
                                checkedCheckmarkColor = Helper.Color.White,
                                checkedBoxColor = Helper.Color.Blue,
                                uncheckedBoxColor = Helper.Color.Black3C,
                                checkedBorderColor = Helper.Color.White10,
                                uncheckedBorderColor = Helper.Color.White10
                            )
                        )
                    }
                    Spacer(Modifier.size(10.dp))
                    Helper.Text("Breakfast included")
                }
                Spacer(Modifier.size(16.dp))
                SelectedField(
                    value = destinations[destination].paymentMethod.value,
                    setValue = {
                        alreadyChange()
                        destinations[destination].paymentMethod.value = it
                               },
                    itemsList = Helper.paymentMethod,
                    label = "Payment method",
                    placeholder = "Select payment method",
                    isError = errorM.paymentMethod,
                    errorText = "Select payment method"
                )
                Spacer(Modifier.size(16.dp))
                Row(
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    OwnTextField(
                        value = destinations[destination].hotelExtraFees.value,
                        changeValue = {
                            alreadyChange()
                            destinations[destination].hotelExtraFees.value = it
                                      },
                        label = "Hotel extra fees",
                        prefix = Helper.getCurrencySymbol(destinations[destination].currencyHEF.value),
                        placeholder = "0.00",
                        type = "Double",
                        w = 0.67f,
                    )
                    Spacer(Modifier.fillMaxWidth(0.1f))
                    SelectedField(
                        label = "Currency",
                        value = destinations[destination].currencyHEF.value,
                        itemsList = Helper.getAvailableCurrencies(),
                        setValue = {
                            alreadyChange()
                            destinations[destination].currencyHEF.value = it
                                   },
                    )
                }
                Spacer(Modifier.size(16.dp))
                ImageField(
                    currentUri = destinations[destination].photo.value,
                    popUpImage = { popUpImage=true }
                )
            }
            Spacer(Modifier.size(16.dp))
            OwnTextMultiLineField(
                value = destinations[destination].description.value,
                changeValue = {
                    alreadyChange()
                    destinations[destination].description.value = it
                              },
                label = "Description (Optional)",
                placeholder = "Enter you description here"
            )
            Helper.HDivider()
            if (travelType == Helper.travelTypes[1]) {
                Helper.ButtonGrey(
                    onClick = {
                        errorM.hasError = setError()
                        if (!errorM.hasError) {
                            destination += 1
                            coroutineScope.launch {
                                scrollState.animateScrollTo(0)
                            }
                        }
                    },
                    text = {
                        Row {
                            Icon(
                                tint = Helper.Color.White50,
                                painter = painterResource(R.drawable.ico_add),
                                contentDescription = ""
                            )
                            Text(
                                text = "Add New Destination",
                                color = Helper.Color.White50,
                                fontSize = 16.sp.nonScaledSp,
                                lineHeight = 24.sp.nonScaledSp
                            )
                        }
                    }
                )
            }
            Spacer(Modifier.size(16.dp))
            Helper.ButtonBlue(
                onClick = {
                    errorM.hasError = setError()
                    if (!errorM.hasError) {
                        saveTravel()
                    }
                },
                text = { Helper.Text("Save") }
            )
        }
    }
}
@Composable
fun TravelAutoComplete(
    departureValue:String,
    destinationValue:String,
    itemsList: List<String>,
    setDepartureValue: (String) -> Unit,
    setDestinationValue: (String) -> Unit,
    isDepartureError:Boolean = false,
    isDestinationError:Boolean = false
){
    var expanded by remember { mutableStateOf(false) }
    var current by remember { mutableStateOf("") }

    val items = if (current == "departure" && departureValue.isNotEmpty()) {
            itemsList.filter { it.contains(departureValue, true) }
        } else if (current == "destination" && destinationValue.isNotEmpty()) {
                itemsList.filter { it.contains(destinationValue, true) }
        } else {
            itemsList
        }
    Column(modifier = Modifier.fillMaxWidth()) {
        Row(
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.Top
        ) {
            OwnTextField(
                value = departureValue,
                label = "Departure",
                placeholder = "Departure",
                changeValue = {
                    setDepartureValue(it)
                    expanded = true
                },
                onFocusChanged = {
                    if (!it) {
                        expanded = false
                    } else {
                        current = "departure"
                    }
                },
                isError = isDepartureError,
                errorText = "Please select your departure",
                w = 0.44f
            )
            Column {
                Helper.Text(text = " ")
                Icon(
                    modifier = Modifier.fillMaxWidth(0.21f).padding(top=10.dp),
                    painter = painterResource(R.drawable.ico_plane),
                    contentDescription = ""
                )
            }
            OwnTextField(
                value = destinationValue,
                label = "Destination",
                placeholder = "Destination",
                changeValue = {
                    setDestinationValue(it)
                    expanded = true
                },
                onFocusChanged = {
                    if (!it) {
                        expanded = false
                    } else {
                        current = "destination"
                    }
                },
                isError = isDestinationError,
                errorText = "Please select your destination"
            )
        }
        if (expanded) {
            Card(
                modifier = Modifier
                    .heightIn(max = 150.dp)
                    .background(Helper.Color.Black3C),
                shape = RoundedCornerShape(0.dp)
            ) {
                if (items.isNotEmpty()) {
                    for (index in items.indices) {
                        if (index >= 4) break

                        Row(
                            modifier = Modifier
                                .background(Helper.Color.Black3C)
                                .fillMaxWidth()
                                .clickable {
                                    when (current) {
                                        "departure" -> {
                                            setDepartureValue(items[index])
                                            expanded = false
                                        }

                                        "destination" -> {
                                            setDestinationValue(items[index])
                                            expanded = false
                                        }
                                    }

                                }
                                .padding(5.dp)
                        ) {
                            Helper.Text(text = items[index])
                        }
                    }
                }
            }
        }
    }
}

data class TravelD(
    var departure: MutableState<String>,
    var destination: MutableState<String>,
    var departureDate: MutableState<Long?>,
    var returnDate: MutableState<Long?>,
    var budget: MutableState<String>,
    var placeOfStaying: MutableState<String>,
    var nights: MutableState<String>,
    var arbitraryLocation: MutableState<Boolean>,
    var ratePerNight: MutableState<String>,
    var currencyPN: MutableState<String>,
    var breakfast: MutableState<Boolean>,
    var paymentMethod: MutableState<String>,
    var hotelExtraFees: MutableState<String>,
    var currencyHEF: MutableState<String>,
    var description: MutableState<String>,
    var photo: MutableState<Uri>
)
