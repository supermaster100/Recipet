package com.example.myexpenses.ui.screens.more

import android.annotation.SuppressLint
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material3.BasicAlertDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavController
import com.example.myexpenses.R
import com.example.myexpenses.data.Helper
import com.example.myexpenses.data.Route
import com.example.myexpenses.data.db.Exchange
import com.example.myexpenses.data.db.Leg
import com.example.myexpenses.data.db.Receipt
import com.example.myexpenses.data.db.Travel
import com.example.myexpenses.nonScaledSp
import com.example.myexpenses.ui.AppViewModelProvider
import com.example.myexpenses.ui.components.DoExport
import com.example.myexpenses.ui.components.EmptyList
import com.example.myexpenses.ui.screens.models.DownloadReportModule
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@SuppressLint("CoroutineCreationDuringComposition")
@Composable
fun DownloadReport(
    navController: NavController,
    back: () -> Unit,
    exportModel: DownloadReportModule = viewModel(factory = AppViewModelProvider.Factory),
) {
    val coroutineScope = rememberCoroutineScope()
    var receipts: List<Receipt>? by remember { mutableStateOf(null) }
    if (receipts == null) {
        coroutineScope.launch {
            receipts = exportModel.getReceipts()
        }
        return
    }

    var exchanges: List<Exchange>? by remember { mutableStateOf(null) }
    if (exchanges == null) {
        coroutineScope.launch {
            exchanges = exportModel.getExchanges()
        }
        return
    }

    var legs: List<Leg>? by remember { mutableStateOf(null) }
    var travels: List<Travel>? by remember { mutableStateOf(null) }
    if (legs == null){
        coroutineScope.launch{
            legs = exportModel.getLeg()
        }
        return
    }
    if (legs!!.isNotEmpty()) {
        if (travels == null) {
            coroutineScope.launch {
                travels = exportModel.getTravels(legs!![0].id)
            }
            return
        }
    }

    var doExport by remember { mutableStateOf(false) }
    var exportSuccessfully by remember { mutableStateOf(false) }
    var exportPopUp by remember { mutableStateOf(false) }
    if (exportPopUp) BasicAlertDialog(
        modifier = Helper.modifierAlert,
        onDismissRequest = { exportPopUp = false },
    ) {
        Column(
            modifier = Modifier.padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            content = {
                Helper.TextH2(text = "After this operation, all data will be inaccessible from the application")
                Helper.HDivider()
                Helper.ButtonBlue(
                    onClick = { doExport = true; exportPopUp = false },
                    text = { Helper.Text("Report") }
                )
                Helper.ButtonGrey3C(
                    onClick = { exportPopUp = false },
                    text = { Helper.Text("Cancel") })
            }
        )
    }

    if (doExport) {
        DoExport(
            endExport = {
                if (it != "Error") {
                    exportSuccessfully = true
                    doExport = false
                } else {
                    back()
                }
            }
        )
    } else if (exportSuccessfully) {
        EmptyList(
            ico = painterResource(R.drawable.ico_travel_su),
            text1 = "The report created successfully",
            text2 = "You can now send it via email and add new travel",
        )
    } else if (receipts!!.isEmpty() && exchanges!!.isEmpty() && legs!!.isEmpty() ) {
        EmptyList(
            ico = painterResource(R.drawable.ico_travel_su),
            text1 = "Expenses, Travel and Exchanges are empty",
            text2 = "You can start adding receipts to get expenses report",
            textButton = "Add expenses ",
            clickButton = {navController.navigate(Route.ADD_RECEIPT)},
            customButton = {
                Helper.ButtonGrey(
                    modifier = Modifier.padding(20.dp, 8.dp),
                    onClick = { navController.navigate(Route.ADD_EXCHANGES) },
                    text = {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.Center
                        ) {
                            Icon(
                                modifier = Modifier.padding(end = 8.dp).size(16.dp),
                                painter = painterResource(R.drawable.ico_add),
                                contentDescription = ""
                            )
                            Text(
                                text = "Add exchanges",
                                fontSize = 16.sp.nonScaledSp,
                                lineHeight = 24.sp.nonScaledSp,
                                fontWeight = FontWeight(500)
                            )
                        }
                    }
                )
                Helper.ButtonBlue(
                    modifier = Modifier.padding(20.dp, 8.dp),
                    onClick = { navController.navigate(Route.ADD_TRAVEL) },
                    text = {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.Center
                        ) {
                            Icon(
                                modifier = Modifier.padding(end = 8.dp).size(16.dp),
                                painter = painterResource(R.drawable.ico_add),
                                contentDescription = ""
                            )
                            Text(
                                text = "    Add travel     ",
                                fontSize = 16.sp.nonScaledSp,
                                lineHeight = 24.sp.nonScaledSp,
                                fontWeight = FontWeight(500)
                            )
                        }
                    }
                )
            }
        )
    } else {
        Column(
            modifier = Modifier
                .clip(shape = Helper.bRadius)
                .background(Helper.Color.Black2C)
                .padding(16.dp),
            verticalArrangement = Arrangement.Top
        ) {
            Helper.TextH2(text = "General data")
            Spacer(Modifier.size(16.dp))
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable {
                        navController.navigate(Route.EXPENSES)
                    },
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Column(horizontalAlignment = Alignment.Start) {
                    Helper.TextH6("Number of expenses")
                    Helper.Text(receipts!!.size.toString())
                }
                Text(text = "")
                Column(horizontalAlignment = Alignment.End) {
                    Icon(
                        painter = painterResource(R.drawable.ico_row_right),
                        contentDescription = ""
                    )
                }

            }
            Helper.HDivider()
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable {
                        navController.navigate(Route.EXCHANGES)
                    },
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Column(horizontalAlignment = Alignment.Start) {
                    Helper.TextH6("Number of exchange operation")
                    Helper.Text(exchanges!!.size.toString())
                }
                Text(text = "")
                Column(horizontalAlignment = Alignment.End) {
                    Icon(
                        painter = painterResource(R.drawable.ico_row_right),
                        contentDescription = ""
                    )
                }
            }
            Helper.HDivider()
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable {
                        navController.navigate(Route.TRAVEL)
                    },
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Column(horizontalAlignment = Alignment.Start) {
                    Helper.TextH6("Number of travel destinations")
                    Helper.Text(
                        if (legs!!.isNotEmpty()) {
                            travels!!.size.toString()
                        } else {
                            "0"
                        }
                    )
                }
                Text(text = "")
                Column(horizontalAlignment = Alignment.End) {
                    Icon(
                        painter = painterResource(R.drawable.ico_row_right),
                        contentDescription = ""
                    )
                }
            }
        }
        Spacer(Modifier.size(16.dp))
        Helper.ButtonBlue(
            onClick = {
                exportPopUp = true
            },
            text = { Helper.Text("Download report") },
        )
    }
}
