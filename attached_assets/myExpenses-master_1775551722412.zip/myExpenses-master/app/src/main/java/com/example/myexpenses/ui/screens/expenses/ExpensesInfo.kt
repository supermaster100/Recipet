package com.example.myexpenses.ui.screens.expenses

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.myexpenses.data.Helper
import com.example.myexpenses.data.db.Receipt
import com.example.myexpenses.ui.AppViewModelProvider
import com.example.myexpenses.ui.components.ImageField
import com.example.myexpenses.ui.components.OwnTextMultiLineField
import com.example.myexpenses.ui.components.PhotoPopUp
import com.example.myexpenses.ui.screens.models.MediaStoreModel

@Composable
fun ExpensesInfo(
    receipt: Receipt,
    editExchange: (Receipt) -> Unit,
    viewMedia: MediaStoreModel = viewModel(factory = AppViewModelProvider.Factory)
) {
    val focusRequester = remember { FocusRequester() }
    var edit: Int by remember { mutableIntStateOf(0) }
    var editValue: String by remember { mutableStateOf("") }
    val resetEdit = {
        edit = 0
        editValue = ""
    }

    var popUpImage by remember { mutableStateOf(false) }
    if (popUpImage) PhotoPopUp(
        cancel = { popUpImage = false },
        changeImage = {
            editExchange(receipt.copy(
                photo = if (receipt.photo.isEmpty()) {
                    viewMedia.saveToLocal(it.toString())
                } else {
                    viewMedia.saveToLocal(it.toString(),receipt.photo)
                }
            ))
            popUpImage = false
        }
    )

    Column(
        modifier = Modifier
            .verticalScroll(rememberScrollState())
    ) {
        ImageField(
            currentUri = receipt.photo,
            popUpImage = { popUpImage = true },
            title = null
        )
        Spacer(Modifier.size(16.dp))
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .clip(Helper.bRadius)
                .background(Helper.Color.Black2C)
                .padding(16.dp)
        ) {
            Helper.TextH2(text = "General Info")
            Spacer(Modifier.size(16.dp))
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(Helper.bRadius)
                    .background(Helper.Color.Black3C)
                    .padding(16.dp)
            ) {
                Helper.TextH6("Expenses type")
                Helper.Text(receipt.expensesType)
                Helper.HDivider()
                Helper.TextH6("Budget number")
                Helper.Text(receipt.budget)
                Helper.HDivider()
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Column(horizontalAlignment = Alignment.Start) {
                        Helper.TextH6("Amount")
                        Helper.Text(
                            "${Helper.getCurrencySymbol(receipt.currency)}${Helper.formatDouble(receipt.amount)}"
                        )
                    }
                    Text(text = "")
                    Column(horizontalAlignment = Alignment.End) {
                        Helper.TextH6("Currency")
                        Helper.Text(receipt.currency)
                    }
                }
                Helper.HDivider()
                Helper.TextH6("Number of people")
                Helper.Text(receipt.numberOfPeople)
                Helper.HDivider()
                Helper.TextH6("Date of paying")
                Helper.Text(Helper.fData(receipt.payingDate))
            }
            Spacer(Modifier.size(16.dp))
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(Helper.bRadius)
                    .background(Helper.Color.Black3C)
                    .padding(16.dp)
            ) {
                Helper.TextH6("Description")

                if (edit == 2) {
                    OwnTextMultiLineField(
                        modifier = Modifier.focusRequester(focusRequester),
                        value = editValue,
                        changeValue = { editValue = it },
                        label = null,
                        placeholder = "Enter you description here"
                    )
                    Helper.TextH6(
                        text = "Save",
                        modifier = Modifier
                            .drawBehind {
                                val strokeWidthPx = 1.dp.toPx()
                                val verticalOffset = size.height - 2.sp.toPx()
                                drawLine(
                                    color = Color(0xFFF3F3F3),
                                    strokeWidth = strokeWidthPx,
                                    start = Offset(0f, verticalOffset),
                                    end = Offset(size.width, verticalOffset)
                                )
                            }
                            .clickable {
                                editExchange(receipt.copy(description = editValue))
                                resetEdit()
                            }
                    )
                    LaunchedEffect(Unit) {
                        focusRequester.requestFocus()
                    }
                } else {
                    Helper.Text(receipt.description)
                    Helper.TextH6(
                        text = "Edit",
                        modifier = Modifier
                            .drawBehind {
                                val strokeWidthPx = 1.dp.toPx()
                                val verticalOffset = size.height - 2.sp.toPx()
                                drawLine(
                                    color = Color(0xFFF3F3F3),
                                    strokeWidth = strokeWidthPx,
                                    start = Offset(0f, verticalOffset),
                                    end = Offset(size.width, verticalOffset)
                                )
                            }
                            .clickable {
                                edit = 2
                                editValue = receipt.description
                            }
                    )
                }
            }
        }
    }
}
