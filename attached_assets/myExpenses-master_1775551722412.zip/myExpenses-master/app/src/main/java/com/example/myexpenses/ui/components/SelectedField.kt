package com.example.myexpenses.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.interaction.Interaction
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.PressInteraction
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import com.example.myexpenses.R
import com.example.myexpenses.data.Helper
import kotlinx.coroutines.channels.BufferOverflow
import kotlinx.coroutines.flow.MutableSharedFlow

@Composable
fun SelectedField(
    value: String,
    itemsList: Array<String>,
    setValue: (String) -> Unit,
    label: String = "Label",
    placeholder: String = "Select",
    isError: Boolean = false,
    valueWrap: (String) -> String = {it},
    w: Float = 1f,
    errorText: String = "Missing Field",
    enabled:Boolean = true
) {
    var expanded: Boolean by remember { mutableStateOf(false) }
    var ws by remember { mutableStateOf(0.dp) }
    Box(
        Modifier.fillMaxWidth(w)
    ) {
        OwnTextField(
            value = valueWrap(value),
            readOnly = true,
            enabled = enabled,
            label = label,
            placeholder = placeholder,
            interactionSource = remember {
                object : MutableInteractionSource {
                    override val interactions = MutableSharedFlow<Interaction>(
                        extraBufferCapacity = 16,
                        onBufferOverflow = BufferOverflow.DROP_OLDEST,
                    )
                    override suspend fun emit(interaction: Interaction) {
                        when (interaction) {
                            is PressInteraction.Press -> {
                                expanded = !expanded
                            }
                        }
                        interactions.emit(interaction)
                    }
                    override fun tryEmit(interaction: Interaction): Boolean {
                        return interactions.tryEmit(interaction)
                    }
                }
            },
            isError = isError,
            getBasicTextFieldWidth={ws = it},
            rightIcon = if (expanded) painterResource(R.drawable.ico_row_up) else painterResource(R.drawable.ico_row_down),
            errorText = errorText
        )
        DropdownMenu(
            expanded = expanded,
            onDismissRequest = { expanded = false },
            modifier = Modifier
                .width(ws)
                .heightIn(max = 400.dp)
                .border(
                    width = 1.5.dp,
                    color = Helper.Color.White10,
                    shape = Helper.bRadius
                )
                .background(Helper.Color.Black3C),
            content = {
                itemsList.forEachIndexed { i, item ->
                    DropdownMenuItem(
                        text = {
                            Column(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalAlignment = Alignment.Start
                            ) {
                                if (i == 0) {
                                    Spacer(Modifier.size(16.dp))
                                }
                                Helper.Text(text = valueWrap(item))
                                if (i < itemsList.size - 1) {
                                    Helper.HDivider()
                                } else {
                                    Spacer(Modifier.size(16.dp))
                                }
                            }
                        },
                        onClick = {
                            expanded = false
                            setValue(item)
                        }
                    )
                }
            }
        )
    }
}