package com.example.myexpenses.data

import android.annotation.SuppressLint
import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.media.ExifInterface
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Environment
import android.provider.DocumentsContract
import android.provider.MediaStore
import android.util.Log
import androidx.camera.core.ImageCapture
import androidx.core.net.toUri
import com.example.myexpenses.R
import com.example.myexpenses.data.db.Exchange
import com.example.myexpenses.data.db.General
import com.example.myexpenses.data.db.Receipt
import com.example.myexpenses.data.db.Travel
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.IOException
import java.io.OutputStream
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale


class CMediaStore(private val context: Context) {
    private val dirPictures = "Pictures/" + context.resources.getString(R.string.app_name)
    private val dirLocal = context.filesDir

    private val newFileName = "yyyyMMdd_HHmmss"
    var runDetImageUriForDeleteModule = true

    @SuppressLint("SimpleDateFormat")
    fun takePicture(
        imageCapture: ImageCapture,
        callBack: ImageCapture.OnImageSavedCallback
    ) {
        val name = SimpleDateFormat(newFileName).format(Date())

        val contentValues = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, name)
            put(MediaStore.MediaColumns.MIME_TYPE, "image/jpeg")
            put(MediaStore.Images.Media.RELATIVE_PATH, dirPictures)
        }

        val outputOptions = ImageCapture.OutputFileOptions
            .Builder(
                context.contentResolver,
                MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                contentValues
            )
            .build()

        imageCapture.takePicture(outputOptions, context.mainExecutor, callBack)
    }

    private fun getFilePath(uri: Uri): String {
        val projection = arrayOf(MediaStore.Images.Media.DATA)
        val cursor: Cursor? = context.contentResolver.query(uri, projection, null, null, null)

        if (cursor != null && cursor.moveToFirst()) {
            val columnIndex: Int = cursor.getColumnIndex(projection[0])
            val picturePath = cursor.getString(columnIndex)
            cursor.close()
            return picturePath
        }

        return ""
    }

    fun deletePhotos() {
        try {
            val photoDir = File(Environment.getExternalStorageDirectory().absolutePath + File.separator + dirPictures)
            if (photoDir.exists()) {
                photoDir.listFiles()?.forEach {
                    deletePhoto(it)
                }
            }
        } catch (_: Exception) {
            Log.w("mediaFile", "deletePhotos")
        }
    }

    fun deletePhoto(uri: Uri) {
        try {
            deletePhoto(File(getFilePath(uri)))
        } catch (_: Exception) {
            Log.w("mediaFile", "deletePhotoUri")
        }
    }

    private fun deletePhoto(mediaFile: File) {
        try {
            mediaFile.delete()
            MediaScannerConnection.scanFile(
                context,
                arrayOf(mediaFile.absolutePath),
                null,
                null
            )
        } catch (_: Exception) {
            Log.w("mediaFile", "deletePhoto")
        }
    }

    @SuppressLint("SimpleDateFormat")
    fun saveToLocal(uri: String, random:Boolean = false): String {
        if (uri.isEmpty()) return ""

        val source = context.contentResolver.openInputStream(uri.toUri())
        source?.let { sourceS ->
            try {
                val rand = if (random) (0..10000).random().toString() else ""
                val imageFile = File(dirLocal, "${SimpleDateFormat(newFileName).format(Date())}$rand.jpg")
                val outputStream: OutputStream = FileOutputStream(imageFile)
                val buf = ByteArray(1024)
                var len: Int
                while (source.read(buf).also { len = it } > 0) outputStream.write(buf, 0, len)
                outputStream.close()
                sourceS.close()
                return imageFile.absolutePath
            } catch (ignore: IOException) {

            }
            sourceS.close()
        }
        return ""
    }
    fun getImageCreationDate(uri: Uri): Long? {
        val inputStream = context.contentResolver.openInputStream(uri)
        inputStream?.use { stream ->
            val exifInterface = ExifInterface(stream)
            // Parse the date string
            val dateFormat = SimpleDateFormat("yyyy:MM:dd HH:mm:ss", Locale.getDefault())
            return exifInterface.getAttribute(ExifInterface.TAG_DATETIME)
                ?.let { dateFormat.parse(it)?.time }
        }
        return null
    }

    fun getAllFromLocal(): List<Uri> {
        val list = mutableListOf<Uri>()

        dirLocal.listFiles()?.forEach {
            if (it.extension.equals("jpg", ignoreCase = true)) list.add(it.toUri())
        }
        return list.toList()
    }

    fun deleteFromLocal(path: String) {
        try {
            File(path).delete()
        } catch (_: Exception) {
            Log.w("mediaFile", "saveToLocal")
        }
    }

   @SuppressLint("SimpleDateFormat")
   fun doExport(
       uri: Uri?,
       general: General,
       travelList: List<Travel>?,
       expensesList: List<Receipt>,
       exchangesList: List<Exchange>,
       countryFromJson: List<List<String>>,
    ):String{
        var exDir = "Error"
        uri?.let {rootUri ->
            val docId = DocumentsContract.getTreeDocumentId(rootUri)
            val dirUri = DocumentsContract.buildDocumentUriUsingTree(rootUri, docId)
            val date = SimpleDateFormat(newFileName).format(Calendar.getInstance().time)
            val dirName= "Expenses_${date}"
            dirUri?.let {rootDir ->
                val directoryUri = DocumentsContract.createDocument(context.contentResolver,  rootDir, DocumentsContract.Document.MIME_TYPE_DIR, dirName)
                directoryUri?.let {subDir ->
                    val fileUri = DocumentsContract.createDocument(context.contentResolver, subDir, "application/excel", "${dirName}.csv")
                    fileUri?.let {file ->
                        val stream = context.contentResolver.openOutputStream(file)
                        stream?.let {newFile ->
                            val images = mutableListOf<List<String>>()

                            var csvText = "G,${general.workerNumber},${general.department},${general.monthYear}\n"
                            if (travelList != null) {
                                travelList!!.forEach { travel ->
                                    var id = countryFromJson[0].indexOf(travel.departure)
                                    var countryD = ""
                                    var regionD = ""
                                    if (id != -1) {
                                        countryD = countryFromJson[id + 1][0]
                                        regionD = countryFromJson[id + 1][1]
                                    }

                                    id = countryFromJson[0].indexOf(travel.destination)
                                    var countryA = ""
                                    var regionA = ""
                                    if (id != -1) {
                                        countryA = countryFromJson[id + 1][0]
                                        regionA = countryFromJson[id + 1][1]
                                    }

                                    csvText += "T,${Helper.fData(travel.departureDate)},${countryD},${regionD},${
                                        Helper.fData(
                                            travel.returnDate
                                        )
                                    },${countryA},${regionA},${travel.budget}\n"

                                    var name = ""
                                    if (travel.photo.isNotEmpty() && File(travel.photo).exists()) {
                                        name = File(travel.photo).name
                                        images.add(listOf(name, travel.photo))
                                    }
                                    csvText += "H,${travel.placeOfStaying},${travel.nights},${if (travel.arbitraryLocation) "Y" else "N"},"
                                    csvText +=
                                        if (travel.arbitraryLocation)
                                            ",,,,,,${travel.description},\n"
                                        else
                                            "${
                                                travel.ratePerNight.replace(
                                                    ",",
                                                    "."
                                                )
                                            },${travel.currencyPN},${if (travel.paymentMethod == "Card") "CC" else "C"},${if (travel.breakfast) "Y" else "N"},${
                                                travel.hotelExtraFees.replace(
                                                    ",",
                                                    "."
                                                )
                                            },${
                                                travel.currencyHEF.replace(
                                                    ",",
                                                    "."
                                                )
                                            },${travel.description},${name}\n"
                                }
                            }
                            expensesList.forEach { expense ->
                                var name = ""
                                if ( expense.photo.isNotEmpty() && File(expense.photo).exists()
                                ) {
                                    name = File(expense.photo).name
                                    images.add(listOf(name, expense.photo))
                                }
                                csvText += "E,${expense.expensesType},${expense.amount.replace(",",".")},${expense.currency},${Helper.fData(expense.payingDate)},${expense.numberOfPeople},${expense.budget},${expense.description},${name}\n"
                            }
                            exchangesList.forEach { exchange ->
                                var name = ""
                                if (exchange.photo.isNotEmpty() && File(exchange.photo).exists()) {
                                    name = File(exchange.photo).name
                                    images.add(listOf(name, exchange.photo))
                                }
                                csvText += "X,${Helper.fData(exchange.dateOfExchange)},${exchange.amountSpent.replace(",",".")},${exchange.spentCurrency},${exchange.amountReceived.replace(",",".")},${exchange.receivedCurrency},${exchange.description},${name}\n"
                            }
                            val data = csvText.toByteArray()
                            newFile.write(data)
                            newFile.close()
                            exDir = subDir.lastPathSegment?:""

                            if (images.isNotEmpty()) {
                                val imgDirUri = DocumentsContract.createDocument(context.contentResolver, subDir, DocumentsContract.Document.MIME_TYPE_DIR, "img")
                                imgDirUri?.let { imgDir ->
                                    images.forEach { image ->
                                        val source = FileInputStream(File(image[1]))
                                        val imageFileUri = DocumentsContract.createDocument(
                                            context.contentResolver,
                                            imgDir,
                                            "image/jpeg",
                                            image[0]
                                        )
                                        imageFileUri?.let { imgFileUri ->
                                            val destination =
                                                context.contentResolver.openOutputStream(imgFileUri)
                                            destination?.let { copy ->
                                                copy.write(source.readBytes())
                                                copy.close()
                                            }
                                        }
                                        source.close()
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        return exDir
    }
    fun getCountryFromJson():String{
        return context.assets.open("CountriesAndCities.json").bufferedReader().use { it.readText() }
    }
}