package com.example.myexpenses.ui.components

import androidx.compose.foundation.layout.Column
import androidx.compose.material3.BasicAlertDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.text.style.TextAlign
import com.example.myexpenses.data.Helper


@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun UnsavedChanges(
    back: () -> Unit,
    dismiss: () -> Unit
) {
    BasicAlertDialog(
        modifier = Helper.modifierAlert,
        onDismissRequest = { dismiss() },
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            content = {
                Helper.TextH2("You have unsaved changes", TextAlign.Center)
                Helper.HDivider()
                Helper.Text("Are you sure you want to go back to the previous page? All of your entered data will be lost.", textAlign = TextAlign.Center)
                Helper.HDivider()
                Helper.ButtonBlue(onClick = { dismiss() }, text = { Helper.Text("Continue editing") })
                Helper.ButtonGrey(onClick = { back() }, text = { Helper.Text("Abort editing") })
            }
        )
    }
}