package com.example.myexpenses.ui.screens.more

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.unit.dp
import com.example.myexpenses.data.Helper
import com.example.myexpenses.data.db.Budget
import com.example.myexpenses.ui.components.OwnTextField

@Composable
fun  BudgetEdit (
    alreadyChange: () -> Unit = {},
    saveChange: (Budget) -> Unit
){
    val values = object {
        var budgetNumber: String by remember { mutableStateOf("") }
        var budgetNumberName: String by remember { mutableStateOf("") }

        fun saveChange() {
            saveChange(
                Budget(
                    budgetNumber = this.budgetNumber,
                    budgetNumberName = this.budgetNumberName
                )
            )
        }
    }

    val errorM = object {
        var budgetNumber: Boolean by remember { mutableStateOf(false) }
        var budgetNumberName: Boolean by remember { mutableStateOf(false) }
        var hasError: Boolean by remember { mutableStateOf(false) }
    }
    val setError = fun(): Boolean {
        errorM.budgetNumber = values.budgetNumber.isEmpty()
        errorM.budgetNumberName = values.budgetNumberName.isEmpty()

        return errorM.budgetNumber || errorM.budgetNumberName
    }
    if (errorM.hasError) {
        errorM.hasError = setError()
    }
    Column(
        modifier = Modifier
            .clip(shape = Helper.bRadius)
            .background(Helper.Color.Black3C)
            .padding(12.dp),
        verticalArrangement = Arrangement.Top
    ) {
        OwnTextField(
            value = values.budgetNumber,
            label = "Budget number",
            changeValue = {
                alreadyChange()
                values.budgetNumber = it
                          },
            isError = errorM.budgetNumber,
            errorText = "Please enter the budget number",
            type = "Int"
        )
        Spacer(Modifier.size(12.dp))
        OwnTextField(
            value = values.budgetNumberName,
            label = "Department",
            changeValue = {
                alreadyChange()
                values.budgetNumberName = it
                          },
            isError = errorM.budgetNumberName,
            errorText = "Please enter the budget number name",
        )
        Spacer(Modifier.size(20.dp))
        Helper.ButtonBlue(
            onClick = {
                errorM.hasError = setError()
                if (!errorM.hasError) {
                    values.saveChange()
                }
            },
            text = { Helper.Text("Save changes") }
        )
    }
}