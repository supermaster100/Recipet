package com.example.myexpenses.ui.screens.more

import android.content.pm.PackageInfo
import android.content.pm.PackageManager
import androidx.compose.foundation.layout.Column
import androidx.compose.material3.BasicAlertDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import com.example.myexpenses.data.Helper

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AboutApp(
    popUpAbout: () -> Unit
) {
    val activity = LocalContext.current
    val packageInfo: PackageInfo? = try {
        activity.packageManager.getPackageInfo(activity.packageName, 0)
    } catch (e: PackageManager.NameNotFoundException) {
        null
    }

    val versionName = packageInfo?.versionName ?: "Unknown"

    BasicAlertDialog(
        modifier = Helper.modifierAlert,
        onDismissRequest = { popUpAbout() },
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Helper.TextH2(text = "About")
            Helper.HDivider()
            Helper.Text(text = "Version $versionName\r\n©2024.02.12", textAlign = TextAlign.Center)
            Helper.HDivider()
            Helper.ButtonBlue({ popUpAbout() }, { Helper.Text("OK") })
        }
    }
}