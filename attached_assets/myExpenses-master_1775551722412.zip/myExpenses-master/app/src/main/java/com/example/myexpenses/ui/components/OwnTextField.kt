package com.example.myexpenses.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.painter.Painter
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.myexpenses.data.Helper
import com.example.myexpenses.nonScaledSp

@Composable
fun OwnTextField(
    value: String = "",
    prefix: String = "",
    label: String? = "Label",
    placeholder: String = "Enter Here",
    changeValue: (String) -> Unit = {},
    isError: Boolean = false,
    errorText: String = "Missing Field",
    w: Float = 1f,
    type: String = "",
    interactionSource: MutableInteractionSource = remember { MutableInteractionSource() },
    readOnly: Boolean = false,
    getBasicTextFieldWidth: (Dp) -> Unit = {},
    onFocusChanged: (Boolean) -> Unit = {},
    rightIcon: Painter? = null,
    enabled: Boolean = true,
    modifier: Modifier = Modifier
) {
    var isFocused by remember { mutableStateOf(false) }
    val localDensity = LocalDensity.current
    Column(
        modifier = Modifier
            .fillMaxWidth(w)
            .onGloballyPositioned { coordinates ->
                getBasicTextFieldWidth(with(localDensity) { coordinates.size.width.toDp() })
            },
    ) {
        if (label != null) {
            Helper.Text(label)
        }
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(48.dp)
                .border(
                    1.5.dp,
                    if (isFocused) Helper.Color.Blue
                    else Helper.Color.White70,
                    Helper.bRadius
                )
                .clip(Helper.bRadius).background(Helper.Color.Black3C).padding(16.dp, 12.dp)
        ) {
            Row (
                modifier = Modifier.fillMaxWidth().height(48.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                BasicTextField(
                    modifier = modifier.fillMaxWidth().onFocusChanged {
                        isFocused = it.isFocused
                        onFocusChanged(isFocused)
                    },
                    enabled = enabled,
                    value = "$prefix$value",
                    singleLine = true,
                    interactionSource = interactionSource,
                    readOnly = readOnly,
                    cursorBrush = SolidColor(Helper.Color.White),
                    textStyle = TextStyle(
                        color = if (isError) Helper.Color.Red else Helper.Color.White,
                        fontSize = 16.sp.nonScaledSp,
                        lineHeight = 24.sp.nonScaledSp
                    ),
                    onValueChange = {
                        val str = it.removePrefix(prefix)
                        if (str.length <= 150) {
                            when (type) {
                                "Double" -> {
                                    if (str.toDoubleOrNull() != null || str == "") {
                                        changeValue(str)
                                    }
                                }
                                "Int" -> {
                                    if (str.toLongOrNull() != null || str == "") {
                                        changeValue(str)
                                    }
                                }
                                else -> changeValue(str)
                            }
                        }
                    },
                    keyboardOptions = if (type == "Double" || type == "Int")
                        KeyboardOptions.Default.copy(
                            keyboardType = KeyboardType.Number,
                            imeAction = ImeAction.Done
                        )
                    else
                        KeyboardOptions.Default.copy(imeAction = ImeAction.Done)
                )
            }
            if (value.isEmpty() && (!isFocused || readOnly) ) {
                Column (
                    modifier = Modifier.height(48.dp),
                    verticalArrangement = Arrangement.Center
                ) {
                    Text(
                        color = if (isError) Helper.Color.Red else Helper.Color.White50,
                        fontSize = 16.sp.nonScaledSp,
                        lineHeight = 24.sp.nonScaledSp,
                        text = "$prefix$placeholder"
                    )
                }
            }
            if (rightIcon != null) {
                Row (
                    modifier = Modifier
                        .fillMaxWidth()
                        .width(48.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.End
                ){
                    Icon(
                        modifier = Modifier.size(20.dp),
                        tint = if (isError) Helper.Color.Red else Helper.Color.White,
                        painter = rightIcon,
                        contentDescription = ""
                    )
                }
            }
        }
        if (isError) {
            Text(
                modifier = Modifier.fillMaxWidth(),
                text = errorText,
                color = Helper.Color.Red,
                fontSize = 16.sp.nonScaledSp,
                lineHeight = 24.sp.nonScaledSp
            )
        }
    }
}

@Composable
fun OwnTextMultiLineField(
    value: String = "",
    label: String? = "Label",
    placeholder: String = "Enter Here",
    changeValue: (String) -> Unit = {},
    isError: Boolean = false,
    modifier: Modifier = Modifier,
    errorText: String = "Missing Field",
    w: Float = 1f,
) {
    var isFocused by remember { mutableStateOf(false) }
    Column(
        modifier = Modifier
            .fillMaxWidth(w),
        verticalArrangement = Arrangement.Center
    ) {
        if (label != null ) Helper.Text(text = label)
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .border(
                    1.5.dp,
                    if (isFocused) Helper.Color.Blue
                    else Helper.Color.White70,
                    Helper.bRadius
                )
                .clip(Helper.bRadius).background(Helper.Color.Black3C).padding(16.dp, 12.dp)
        ) {
            Column {
                BasicTextField(
                    modifier = modifier
                        .fillMaxWidth()
                        .onFocusChanged {
                            isFocused = it.isFocused
                        },
                    value = value,
                    cursorBrush = SolidColor(Helper.Color.White),
                    maxLines = 5,
                    textStyle = TextStyle(
                        color = if (isError) Helper.Color.Red else Helper.Color.White,
                        fontSize = 16.sp.nonScaledSp,
                        lineHeight = 24.sp.nonScaledSp
                    ),
                    onValueChange = {
                        if ( it.length <= 150 ) {
                            changeValue(it)
                        }
                    },
                    keyboardOptions = KeyboardOptions.Default.copy(imeAction = ImeAction.Done)
                )
                if (value.isNotEmpty()){
                    Text(
                        modifier = Modifier.fillMaxWidth(1f),
                        textAlign = TextAlign.Right,
                        text = "${value.length}/150",
                        fontSize = 12.sp.nonScaledSp,
                        lineHeight = 16.sp.nonScaledSp,
                        color = Helper.Color.White50,
                        fontWeight = FontWeight(500)
                    )
                }
            }
            if (value.isEmpty() && !isFocused) {
                Text(
                    color = if (isError) Helper.Color.Red else Helper.Color.White50,
                    fontSize = 16.sp.nonScaledSp,
                    lineHeight = 24.sp.nonScaledSp,
                    text = placeholder
                )
            }
        }
        if (isError) {
            Text(
                modifier = Modifier.fillMaxWidth(),
                text = errorText,
                color = Color(0xFFEB3737),
                fontSize = 16.sp.nonScaledSp,
                lineHeight = 24.sp.nonScaledSp
            )
        }
    }
}
